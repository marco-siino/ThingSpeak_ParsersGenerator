
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1459026,
        "name": " F. A\u00c7OUGUE 50 -DSB WIFI IOT100/1459026",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2021-07-29T17:45:00Z",
        "updated_at": "2021-09-08T18:02:13Z",
        "last_entry_id": 424954
    },
    "feeds": [
        {
            "created_at": "2024-07-21T20:23:55Z",
            "entry_id": 424954,
            "field1": "27.87500",
            "field2": "25.31250",
            "field3": "28.62500"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema_data = json.loads(schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields based on the semantic of the JSON text
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = None
output_data["pressure"] = None
output_data["light"] = None
output_data["air_quality"] = None
output_data["soil_moisture"] = None
output_data["hardware"] = data["channel"]["name"]
output_data["distance"] = None
output_data["ph"] = None

# Write output JSON to a file
with open("thingspeak/output_json/mistral/1459026.json", "w") as f:
    json.dump(output_data, f, indent=4)
