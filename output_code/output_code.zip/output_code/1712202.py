
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1712202,
        "name": "E2_Zikken_49",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2022-04-23T01:01:55Z",
        "updated_at": "2022-04-23T02:20:27Z",
        "last_entry_id": 2518
    },
    "feeds": [
        {
            "created_at": "2024-04-29T06:41:19Z",
            "entry_id": 2518,
            "field1": "25.80000",
            "field2": "25.80000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output JSON
output = {}
output["id"] = data["channel"]["id"]
output["temperature"] = data["feeds"][0]["field1"]
output["humidity"] = data["feeds"][0]["field2"]
output["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields with null values if not present in the input JSON
for field in schema["properties"]:
    if field not in output:
        output[field] = None

# Write output JSON to file
with open("thingspeak/output_json/mistral/1712202.json", "w") as f:
    json.dump(output, f, indent=4)
