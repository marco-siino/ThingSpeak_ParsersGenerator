
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2146334,
        "name": "Sensor",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humedad",
        "field2": "Temperatura",
        "created_at": "2023-05-13T14:09:34Z",
        "updated_at": "2023-05-13T14:58:16Z",
        "last_entry_id": 374
    },
    "feeds": [
        {
            "created_at": "2023-05-27T19:11:49Z",
            "entry_id": 374,
            "field1": "22.4",
            "field2": "52.2"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant fields from the JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field2"],
    "humidity": data["feeds"][0]["field1"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to a file
with open("thingspeak/output_json/mistral/2146334.json", "w") as f:
    json.dump(output, f, indent=4)
