
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 692353,
        "name": "Measurements",
        "description": "Measurements of temperature and humidity ",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2019-01-31T20:20:40Z",
        "updated_at": "2019-02-01T07:07:21Z",
        "last_entry_id": 9
    },
    "feeds": [
        {
            "created_at": "2019-02-01T07:50:55Z",
            "entry_id": 9,
            "field1": null,
            "field2": "52"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["temperature"] = data["channel"]["field1"] if data["channel"]["field1"] else None
output_data["humidity"] = data["feeds"][0]["field2"] if data["feeds"][0]["field2"] else None

# Write output JSON to file
with open("thingspeak/output_json/mistral/692353.json", "w") as f:
    json.dump(output_data, f, indent=4)
