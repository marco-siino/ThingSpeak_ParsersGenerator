
import json
import os

# JSON text
json_text = """
{
    "channel": {
        "id": 983972,
        "name": "ledblink",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "led3",
        "created_at": "2020-02-07T04:17:57Z",
        "updated_at": "2020-02-07T04:18:31Z",
        "last_entry_id": 13
    },
    "feeds": [
        {
            "created_at": "2020-02-11T05:47:12Z",
            "entry_id": 13,
            "field1": "1"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Create output JSON according to the schema
output_json = {
    "id": data['channel']['id'],
    "temperature": None,
    "humidity": None,
    "pressure": None,
    "light": data['channel']['field1'],
    "air_quality": None,
    "location": data['channel']['location'],
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON into a file
output_path = "thingspeak/output_json/mistral/983972.json"
with open(output_path, 'w') as outfile:
    json.dump(output_json, outfile, indent=4)
