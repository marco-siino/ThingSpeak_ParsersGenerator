
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1676946,
        "name": "Ras pi data",
        "description": "flood detection project ",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "field3": "Distance",
        "created_at": "2022-03-16T08:28:37Z",
        "updated_at": "2022-05-09T13:01:46Z",
        "last_entry_id": 82
    },
    "feeds": [
        {
            "created_at": "2022-05-09T13:09:45Z",
            "entry_id": 82,
            "field1": "30",
            "field2": "47",
            "field3": "74.35625791549683"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["channel"]["field1"]
output_data["humidity"] = data["channel"]["field2"]
output_data["distance"] = data["channel"]["field3"]

# Merge latitude and longitude into location
if data["channel"]["latitude"] != "0.0" and data["channel"]["longitude"] != "0.0":
    output_data["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Fill other fields with null values
for field in schema["properties"].keys():
    if field not in output_data:
        output_data[field] = None

# Prepare feeds data
feeds_data = []
for feed in data["feeds"]:
    feeds_data.append({
        "created_at": feed["created_at"],
        "entry_id": feed["entry_id"],
        "temperature": feed["field1"],
        "humidity": feed["field2"],
        "distance": feed["field3"]
    })

# Add feeds data to output data
output_data["feeds"] = feeds_data

# Write output to file
with open("thingspeak/output_json/mistral/1676946.json", "w") as f:
    json.dump(output_data, f, indent=4)
