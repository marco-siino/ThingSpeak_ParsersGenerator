
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 424653,
        "name": "Sensor DTH11",
        "description": "Sensor que lee la temperatura y la humedad",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Humedad",
        "created_at": "2018-02-10T21:48:02Z",
        "updated_at": "2018-02-10T23:16:35Z",
        "last_entry_id": 242
    },
    "feeds": [
        {
            "created_at": "2018-02-10T23:16:35Z",
            "entry_id": 242,
            "field1": "28",
            "field2": "59"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output = {}
output['id'] = data['channel']['id']
output['temperature'] = data['feeds'][0]['field1']
output['humidity'] = data['feeds'][0]['field2']

# Fill other fields with null values
output['pressure'] = None
output['light'] = None
output['air_quality'] = None
output['soil_moisture'] = None
output['hardware'] = None
output['distance'] = None
output['ph'] = None

# Write output JSON to file
with open('thingspeak/output_json/mistral/424653.json', 'w') as f:
    json.dump(output, f, indent=4)
