
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1065879,
        "name": "Google Assistance Home Automation",
        "description": "This project is to create a google assistance home automation",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "light",
        "created_at": "2020-05-22T09:51:55Z",
        "updated_at": "2020-05-22T09:57:02Z",
        "last_entry_id": 30
    },
    "feeds": [
        {
            "created_at": "2020-05-25T10:51:27Z",
            "entry_id": 30,
            "field1": "1"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["light"] = data["channel"]["field1"]

# Fill other fields with values from the JSON text if available, otherwise leave as null
for field in schema["properties"]:
    if field in data["channel"]:
        output_data[field] = data["channel"][field]
    else:
        output_data[field] = None

# Write output JSON to file
with open("thingspeak/output_json/mistral/1065879.json", "w") as f:
    json.dump(output_data, f, indent=4)
