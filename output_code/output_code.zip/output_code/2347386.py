
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2347386,
        "name": "DHT22 with Thinkspeak",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2023-11-16T14:12:23Z",
        "updated_at": "2023-11-16T14:15:19Z",
        "last_entry_id": 31
    },
    "feeds": [
        {
            "created_at": "2023-11-16T14:33:02Z",
            "entry_id": 31,
            "field1": "8.70000",
            "field2": "50.50000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Extract relevant fields from data
output = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field1'],
    "humidity": data['feeds'][0]['field2'],
    "location": data['channel']['location'],
    # Add other fields as null if not present in the JSON text
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output to file
with open("thingspeak/output_json/mistral/2347386.json", "w") as f:
    json.dump(output, f, indent=4)
