
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2111725,
        "name": "IoT lecture 3 example",
        "description": "this is the description",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "humidity",
        "field2": "temperature",
        "created_at": "2023-04-18T15:12:08Z",
        "updated_at": "2023-04-18T15:13:56Z",
        "last_entry_id": 6
    },
    "feeds": [
        {
            "created_at": "2023-04-18T15:25:50Z",
            "entry_id": 6,
            "field1": null,
            "field2": "400"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0].get("field2", None)
output_data["humidity"] = data["channel"]["field1"]
location = data["channel"]["latitude"] + "," + data["channel"]["longitude"]
output_data["location"] = location

# Write output JSON to file
with open("thingspeak/output_json/mistral/2111725.json", "w") as f:
    json.dump(output_data, f, indent=4)
