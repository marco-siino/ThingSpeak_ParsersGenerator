
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1596568,
        "name": "My Channel",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "created_at": "2021-12-04T17:11:25Z",
        "updated_at": "2021-12-08T14:07:24Z",
        "last_entry_id": 31
    },
    "feeds": [
        {
            "created_at": "2021-12-08T14:03:41Z",
            "entry_id": 31,
            "field1": "30"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["temperature"] = data["channel"]["field1"] if data["channel"]["field1"] else None

# Fill other fields if present in the JSON text
for key in data["channel"]:
    if key not in output_data and key not in ["id", "latitude", "longitude", "field1"]:
        output_data[key] = data["channel"][key]

# Fill feeds if present in the JSON text
for feed in data["feeds"]:
    for key in feed:
        if key not in output_data and key not in ["created_at", "entry_id"]:
            output_data[key] = feed[key]

# Write output JSON to file
with open("thingspeak/output_json/mistral/1596568.json", "w") as f:
    json.dump(output_data, f, indent=4)
