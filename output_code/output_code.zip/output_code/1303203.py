
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1303203,
        "name": "P\u00e1jaros en la nube",
        "latitude": "43.395199",
        "longitude": "-3.824276",
        "field1": "Temperatura",
        "field2": null,
        "created_at": "2021-02-11T12:32:57Z",
        "updated_at": "2021-02-12T10:43:51Z",
        "last_entry_id": 6065
    },
    "feeds": [
        {
            "created_at": "2021-05-15T10:42:36Z",
            "entry_id": 6065,
            "field1": "18.80",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = None  # null value in the schema, so we leave it as None
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["pressure"] = None  # null value in the schema, so we leave it as None
output_data["light"] = None  # not present in the JSON text, so we leave it as None
output_data["air_quality"] = None  # not present in the JSON text, so we leave it as None
output_data["soil_moisture"] = None  # not present in the JSON text, so we leave it as None
output_data["hardware"] = None  # not present in the JSON text, so we leave it as None
output_data["distance"] = None  # not present in the JSON text, so we leave it as None
output_data["ph"] = None  # not present in the JSON text, so we leave it as None

# Write output JSON to a file
with open("thingspeak/output_json/mistral/1303203.json", "w") as f:
    json.dump(output_data, f, indent=4)
