
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 557087,
        "name": "Dust",
        "description": "\ubbf8\uc138\uba3c\uc9c0 \uce21\uc815\uae30",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "PM10",
        "created_at": "2018-08-10T02:59:58Z",
        "updated_at": "2018-08-10T03:31:43Z",
        "last_entry_id": 24
    },
    "feeds": [
        {
            "created_at": "2018-11-15T12:51:53Z",
            "entry_id": 24,
            "field1": "1.64    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Create an empty output dictionary with the schema properties
output = {}
for key in json.loads(json_schema)["properties"]:
    output[key] = None

# Fill the output dictionary with values from the JSON text
output['id'] = data['channel']['id']
output['air_quality'] = data['channel']['field1']
output['location'] = data['channel']['location']

# If there is a feed, fill the rest of the fields
if len(data['feeds']) > 0:
    feed = data['feeds'][0]
    output['temperature'] = feed.get('temperature', None)
    output['humidity'] = feed.get('humidity', None)
    output['pressure'] = feed.get('pressure', None)
    output['light'] = feed.get('light', None)
    output['soil_moisture'] = feed.get('soil_moisture', None)
    output['hardware'] = feed.get('hardware', None)
    output['distance'] = feed.get('distance', None)
    output['ph'] = feed.get('ph', None)

# Write the output JSON to a file
with open('thingspeak/output_json/mistral/557087.json', 'w') as f:
    json.dump(output, f, indent=4)
