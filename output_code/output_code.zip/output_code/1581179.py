
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1581179,
        "name": "Humidity and Temp",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "field2": "Temperature",
        "created_at": "2021-11-23T06:35:24Z",
        "updated_at": "2021-11-23T06:36:37Z",
        "last_entry_id": 5
    },
    "feeds": [
        {
            "created_at": "2021-11-23T07:02:04Z",
            "entry_id": 5,
            "field1": "75",
            "field2": null
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Extract relevant fields from the JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"] if data["feeds"][0]["field1"] else None,
    "humidity": data["feeds"][0]["field2"] if data["feeds"][0]["field2"] else None,
    "location": data["location"],
    # Add other fields as empty strings if not present in the JSON text
    "pressure": "",
    "light": "",
    "air_quality": "",
    "soil_moisture": "",
    "hardware": "",
    "distance": "",
    "ph": ""
}

# Write output to a file
with open("thingspeak/output_json/mistral/1581179.json", "w") as f:
    json.dump(output, f, indent=4)
