
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 583597,
        "name": "ESP8266_BMP280",
        "description": "ESP8266 mit BMP280",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temp",
        "field2": "Pressure",
        "created_at": "2018-09-25T22:25:03Z",
        "updated_at": "2020-05-18T21:04:06Z",
        "last_entry_id": 146869
    },
    "feeds": [
        {
            "created_at": "2023-02-19T20:03:51Z",
            "entry_id": 146869,
            "field1": "20.55000",
            "field2": "1012.62659"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract necessary data from JSON text
channel = data['channel']
feed = data['feeds'][0]

# Merge latitude and longitude into location
location = f"{channel['latitude']}, {channel['longitude']}"

# Create output JSON
output = {
    "id": channel['id'],
    "temperature": feed['field1'],
    "pressure": feed['field2'],
    "location": location,
    # Add other fields with null values if not present in the JSON text
    "humidity": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/583597.json", "w") as f:
    json.dump(output, f, indent=4)
