
import json

def merge_location(data):
    if data['channel']['latitude'] and data['channel']['longitude']:
        data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"
        del data['channel']['latitude']
        del data['channel']['longitude']
    return data

def write_to_file(data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 627940,
        "name": "Temperature",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "created_at": "2018-11-15T17:45:06Z",
        "updated_at": "2018-11-28T05:42:07Z",
        "last_entry_id": 768
    },
    "feeds": [
        {
            "created_at": "2018-12-10T04:12:54Z",
            "entry_id": 768,
            "field1": "31.00"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)
data = merge_location(data)

# Create output JSON based on schema
output_data = {}
for key, value in json.loads(json_schema)['properties'].items():
    if key in data['channel']:
        output_data[key] = data['channel'][key]

# Add feeds data
output_data['feeds'] = data['feeds']

# Write output JSON to file
write_to_file(output_data, 'thingspeak/output_json/mistral/627940.json')
