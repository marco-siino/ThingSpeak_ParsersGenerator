
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 300381,
        "name": "apiit",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2017-07-10T11:22:25Z",
        "updated_at": "2017-09-16T19:27:44Z",
        "last_entry_id": 3
    },
    "feeds": [
        {
            "created_at": "2017-07-10T12:25:59Z",
            "entry_id": 3,
            "field1": "1000",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Create an empty output object
output = {}

# Iterate through the properties in the schema and fill the output object
for key, value in json.loads(json_schema)['properties'].items():
    if key in data['channel']:
        output[key] = data['channel'][key]

    # If feeds exist, iterate through them and fill the output object
    if 'feeds' in data and len(data['feeds']) > 0:
        for feed in data['feeds']:
            for feed_key, feed_value in feed.items():
                if key in feed and feed_value is not None:
                    if key not in output:
                        output[key] = []
                    output[key].append(feed_value)

# Write the output JSON to a file
with open('thingspeak/output_json/mistral/300381.json', 'w') as f:
    json.dump(output, f, indent=4)
