
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1640057,
        "name": "Weather_Station",
        "description": "My Weather station",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Light",
        "created_at": "2022-01-25T14:32:52Z",
        "updated_at": "2022-01-25T14:33:01Z",
        "last_entry_id": 29479
    },
    "feeds": [
        {
            "created_at": "2022-01-31T04:03:47Z",
            "entry_id": 29479,
            "field1": "30",
            "field2": "68",
            "field3": "20.458555"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the "channel" object
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["feeds"][0]["field1"],
    "humidity": data["channel"]["feeds"][0]["field2"],
    "light": data["channel"]["feeds"][0]["field3"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}" if float(data['channel']['latitude']) and float(data['channel']['longitude']) else None,
    # Add other fields with null values if they are not present in the JSON text
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output to a file
with open("thingspeak/output_json/mistral/1640057.json", "w") as f:
    json.dump(output, f, indent=4)
