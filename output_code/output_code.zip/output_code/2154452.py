
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2154452,
        "name": "temp",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "created_at": "2023-05-19T01:04:28Z",
        "updated_at": "2023-07-13T13:44:07Z",
        "last_entry_id": 31
    },
    "feeds": [
        {
            "created_at": "2023-07-13T13:39:36Z",
            "entry_id": 31,
            "field1": "51"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Fill other fields with null values if not present in the JSON text
for field in schema["properties"]:
    if field not in output_data:
        output_data[field] = None

# Write output JSON to file
with open("thingspeak/output_json/mistral/2154452.json", "w") as f:
    json.dump(output_data, f, indent=4)
