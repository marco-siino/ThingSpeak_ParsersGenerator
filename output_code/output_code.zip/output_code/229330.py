
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 229330,
        "name": "IoT workshop by Pannee",
        "description": "Temperature and humidity sensors ",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2017-02-19T03:06:06Z",
        "updated_at": "2017-02-19T06:15:28Z",
        "last_entry_id": 15
    },
    "feeds": [
        {
            "created_at": "2017-02-19T06:15:28Z",
            "entry_id": 15,
            "field1": "24.70",
            "field2": "65.80    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON with schema properties
output_json = {}
for key in json.loads(json_schema)["properties"]:
    output_json[key] = None

# Fill output JSON with data from JSON text
output_json['id'] = data['channel']['id']
output_json['temperature'] = data['channel']['field1']
output_json['humidity'] = data['channel']['field2']
output_json['location'] = data['channel']['location']
output_json['feeds'] = [feed for feed in data['feeds'] if feed]

# Write output JSON to file
with open("thingspeak/output_json/mistral/229330.json", "w") as f:
    json.dump(output_json, f, indent=4)
