
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1310210,
        "name": "temp and humidity sensor",
        "description": "using dht11",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temp",
        "field2": "humidity",
        "created_at": "2021-02-22T05:09:56Z",
        "updated_at": "2021-02-22T05:17:40Z",
        "last_entry_id": 11
    },
    "feeds": [
        {
            "created_at": "2021-02-23T06:11:23Z",
            "entry_id": 11,
            "field1": "33.40",
            "field2": "52.00    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Create output JSON with schema structure
output_json = {
    "id": data['channel']['id'],
    "temperature": data['channel']['field1'],
    "humidity": data['channel']['field2'],
    "location": data['channel']['location'],
    # Add other fields with null values if not present in the input JSON
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Add feeds to output JSON
output_json['feeds'] = data['feeds']

# Write output JSON to file
with open("thingspeak/output_json/mistral/1310210.json", "w") as f:
    json.dump(output_json, f, indent=4)
