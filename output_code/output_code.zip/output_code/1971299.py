
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1971299,
        "name": "Cathiee",
        "description": "temperature and humidity measurement",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "Humidity",
        "created_at": "2022-12-06T05:35:38Z",
        "updated_at": "2022-12-19T09:55:51Z",
        "last_entry_id": 468
    },
    "feeds": [
        {
            "created_at": "2023-01-10T10:02:20Z",
            "entry_id": 468,
            "field1": "28.90000",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Create output JSON with schema structure
output_data = {
    "id": data['channel']['id'],
    "temperature": data['channel']['field1'],
    "humidity": data['channel']['field2'],
    "location": data['channel']['location'],
    # Add other fields from the schema if they exist in the JSON text
    "pressure": data.get('channel', {}).get('field3', None),
    "light": data.get('channel', {}).get('field4', None),
    "air_quality": data.get('channel', {}).get('field5', None),
    "soil_moisture": data.get('channel', {}).get('field6', None),
    "hardware": data.get('channel', {}).get('field7', None),
    "distance": data.get('channel', {}).get('field8', None),
    "ph": data.get('channel', {}).get('field9', None)
}

# Add feeds data if it exists
if 'feeds' in data:
    feed = data['feeds'][0]
    output_data['created_at'] = feed['created_at']
    output_data['entry_id'] = feed['entry_id']

# Write output JSON to file
with open('thingspeak/output_json/mistral/1971299.json', 'w') as f:
    json.dump(output_data, f, indent=4)
