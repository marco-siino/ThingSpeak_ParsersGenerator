
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 812824,
        "name": "Measurements ",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2019-06-29T09:46:32Z",
        "updated_at": "2019-06-29T09:52:29Z",
        "last_entry_id": 22
    },
    "feeds": [
        {
            "created_at": "2019-06-29T10:39:26Z",
            "entry_id": 22,
            "field1": "1",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["channel"]["field1"]
output_data["humidity"] = data["channel"]["field2"] if data["channel"]["field2"] is not None else None
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields with empty strings if not present in the input JSON
for field in ["pressure", "light", "air_quality", "soil_moisture", "hardware", "distance", "ph"]:
    if field not in data["channel"]:
        output_data[field] = ""

# Prepare feeds data
feeds_data = []
for feed in data["feeds"]:
    feeds_data.append({
        "created_at": feed["created_at"],
        "entry_id": feed["entry_id"],
        "temperature": feed["field1"] if "field1" in feed else None,
        "humidity": feed["field2"] if "field2" in feed else None,
    })

# Add feeds data to output data
output_data["feeds"] = feeds_data

# Write output JSON to file
with open("thingspeak/output_json/mistral/812824.json", "w") as f:
    json.dump(output_data, f, indent=4)
