
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 335214,
        "name": "weathermonitoring",
        "description": "checking humidity and temperature",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2017-09-22T05:26:00Z",
        "updated_at": "2017-09-22T05:37:56Z",
        "last_entry_id": 3
    },
    "feeds": [
        {
            "created_at": "2017-09-22T05:37:56Z",
            "entry_id": 3,
            "field1": "24",
            "field2": "30"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output_json = {}

# Extract fields from the JSON text and schema to populate the output JSON
for key, value in data['channel'].items():
    if key in json.loads(json_schema)['properties']:
        output_json[key] = value

for feed in data['feeds']:
    for key, value in feed.items():
        if key in json.loads(json_schema)['properties']:
            if value is not None:
                output_json[key + '_' + str(len(output_json) - 1)] = value

# Write output JSON to file
with open('thingspeak/output_json/mistral/335214.json', 'w') as f:
    json.dump(output_json, f, indent=4)
