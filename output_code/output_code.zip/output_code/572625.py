
import json

def merge_location(data):
    if data["channel"]["latitude"] and data["channel"]["longitude"]:
        data["channel"]["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"
        del data['channel']['latitude']
        del data['channel']['longitude']
    return data

def write_to_file(data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 572625,
        "name": "Maddy_IOT_temp1",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "created_at": "2018-09-09T16:15:28Z",
        "updated_at": "2018-09-09T16:15:28Z",
        "last_entry_id": 40
    },
    "feeds": [
        {
            "created_at": "2018-09-15T16:39:25Z",
            "entry_id": 40,
            "field1": "182.31"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge location field
data = merge_location(data)

# Create output JSON based on schema
output_data = {}
for key, value in json.loads(schema)["properties"].items():
    if key in data["channel"]:
        output_data[key] = data["channel"][key]
    else:
        output_data[key] = None

# Write output JSON to file
write_to_file(output_data, "thingspeak/output_json/mistral/572625.json")
