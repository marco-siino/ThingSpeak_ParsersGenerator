
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 868283,
        "name": "lm35",
        "description": "temperature sensor",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "created_at": "2019-09-21T04:47:11Z",
        "updated_at": "2019-09-21T04:47:30Z",
        "last_entry_id": 2
    },
    "feeds": [
        {
            "created_at": "2019-09-21T04:51:05Z",
            "entry_id": 2,
            "field1": "1"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["channel"]["field1"]
output_data["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Fill other fields with null if not present in the JSON text
for field in schema["properties"]:
    if field in data["channel"]:
        output_data[field] = data["channel"][field]
    else:
        output_data[field] = None

# Prepare output file path
output_file = "thingspeak/output_json/mistral/868283.json"

# Write output data to file
with open(output_file, "w") as f:
    json.dump(output_data, f, indent=4)
