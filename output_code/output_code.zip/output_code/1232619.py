
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1232619,
        "name": "Miria Fritzen DSB Wifi 101/1232619",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2020-11-17T16:48:03Z",
        "updated_at": "2020-11-26T10:39:50Z",
        "last_entry_id": 451806
    },
    "feeds": [
        {
            "created_at": "2024-07-21T12:35:47Z",
            "entry_id": 451806,
            "field1": "19.75000",
            "field2": "18.37500",
            "field3": "23.75000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output data with schema properties
output_data = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0].get('field1', None),
    "humidity": None,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "location": data['channel']['location'],
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Fill other fields in the output JSON according to the semantic of the JSON text
if output_data['temperature'] is not None:
    output_data['humidity'] = data['feeds'][0].get('field2', None)
    output_data['pressure'] = data['feeds'][0].get('field3', None)

# Write the output JSON into a file
with open("thingspeak/output_json/mistral/1232619.json", "w") as f:
    json.dump(output_data, f, indent=4)
