
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1315974,
        "name": "CPE4040",
        "description": "Raspberry pi stuff",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2021-03-01T19:21:04Z",
        "updated_at": "2021-03-01T19:32:52Z",
        "last_entry_id": 1180
    },
    "feeds": [
        {
            "created_at": "2021-03-09T21:20:59Z",
            "entry_id": 1180,
            "field1": "72.3",
            "field2": "32.5"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Create output JSON with schema structure
output_data = {
    "id": data['channel']['id'],
    "temperature": data['channel']['feeds'][0]['field1'],
    "humidity": data['channel']['feeds'][0]['field2'],
    "location": data['channel']['location'],
    # Add other fields from schema with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1315974.json", "w") as f:
    json.dump(output_data, f, indent=4)
