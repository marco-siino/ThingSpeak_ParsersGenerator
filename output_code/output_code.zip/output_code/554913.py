
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 554913,
        "name": "SP-IOT-29",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2018-08-06T03:55:21Z",
        "updated_at": "2019-03-09T15:15:08Z",
        "last_entry_id": 285
    },
    "feeds": [
        {
            "created_at": "2021-09-02T06:10:27Z",
            "entry_id": 285,
            "field1": "23.60",
            "field2": "46.30"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Create output JSON with schema properties
output_json = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field1'],
    "humidity": data['feeds'][0]['field2'],
    "location": data['channel']['location'],
    # Add other properties from the schema with null values if not present in the input JSON
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/554913.json", "w") as f:
    json.dump(output_json, f, indent=4)
