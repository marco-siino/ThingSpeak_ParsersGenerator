
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 24489,
        "name": "Outside",
        "description": "Outside temperature and humidity. Saltsj\u00f6-Boo, Sweden",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2015-01-25T18:59:34Z",
        "updated_at": "2017-06-25T17:06:05Z",
        "last_entry_id": 811101
    },
    "feeds": [
        {
            "created_at": "2019-04-07T13:54:06Z",
            "entry_id": 811101,
            "field1": "9.0",
            "field2": "49"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant data from JSON text
channel = data['channel']
feed = data['feeds'][0]
location = f"{channel['latitude']}, {channel['longitude']}"
temperature = feed['field1']
humidity = feed['field2']

# Create output JSON with schema structure
output = {
    "id": channel['id'],
    "temperature": temperature,
    "humidity": humidity,
    "location": location,
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/24489.json", "w") as f:
    json.dump(output, f, indent=4)
