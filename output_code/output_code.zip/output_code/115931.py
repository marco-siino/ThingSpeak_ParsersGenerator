
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 115931,
        "name": "S15",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2016-05-13T08:29:20Z",
        "updated_at": "2016-10-27T15:29:14Z",
        "last_entry_id": 233055
    },
    "feeds": [
        {
            "created_at": "2016-10-27T15:29:14Z",
            "entry_id": 233055,
            "field1": "22.60",
            "field2": "26.60    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Extract relevant fields from data
output = {
    "id": data['channel']['id'],
    "temperature": data['channel']['field1'],
    "humidity": data['channel']['field2'],
    "location": data['channel']['location'],
    # Add other fields as empty strings if not present in the input data
    "pressure": "",
    "light": "",
    "air_quality": "",
    "soil_moisture": "",
    "hardware": "",
    "distance": "",
    "ph": ""
}

# Create feeds list
feeds = []
for feed in data['feeds']:
    feed_entry = {
        "created_at": feed['created_at'],
        "entry_id": feed['entry_id']
    }
    # Add other fields as empty strings if not present in the feed
    feed_entry["temperature"] = feed.get('field1', "")
    feed_entry["humidity"] = feed.get('field2', "")
    feeds.append(feed_entry)

# Add feeds list to output
output["feeds"] = feeds

# Write output to file
with open("thingspeak/output_json/mistral/115931.json", "w") as f:
    json.dump(output, f, indent=4)
