
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1803687,
        "name": "Wohnung",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatur",
        "field2": "Luftfeuchtigkeit",
        "created_at": "2022-07-18T20:40:52Z",
        "updated_at": "2022-11-16T08:43:43Z",
        "last_entry_id": 66561
    },
    "feeds": [
        {
            "created_at": "2023-05-24T23:10:54Z",
            "entry_id": 66561,
            "field1": "21.00",
            "field2": "67.00"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = data["feeds"][0]["field2"]

# Fill other fields with null values if not present in the JSON text
for field in schema["properties"]:
    if field not in output_data:
        output_data[field] = None

# Write output JSON to file
with open("thingspeak/output_json/mistral/1803687.json", "w") as f:
    json.dump(output_data, f, indent=4)
