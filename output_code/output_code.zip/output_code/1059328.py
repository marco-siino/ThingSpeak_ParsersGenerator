
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1059328,
        "name": "IOT MONITOR",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "field2": "Temperature",
        "created_at": "2020-05-13T14:08:27Z",
        "updated_at": "2020-05-16T21:14:44Z",
        "last_entry_id": 577
    },
    "feeds": [
        {
            "created_at": "2020-05-17T15:18:01Z",
            "entry_id": 577,
            "field1": "85.00",
            "field2": "29.00"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Create output JSON with schema properties
output_json = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field2'],
    "humidity": data['feeds'][0]['field1'],
    "location": data['location'],
    # Add other properties from the schema with null values if not present in the input JSON
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1059328.json", "w") as f:
    json.dump(output_json, f, indent=4)
