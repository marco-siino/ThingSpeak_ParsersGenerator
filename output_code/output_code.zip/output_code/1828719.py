
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1828719,
        "name": "Project",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "field2": "Temperature",
        "created_at": "2022-08-10T08:05:42Z",
        "updated_at": "2022-08-10T08:24:43Z",
        "last_entry_id": 2
    },
    "feeds": [
        {
            "created_at": "2022-08-10T09:13:28Z",
            "entry_id": 2,
            "field1": "62.20000",
            "field2": "27.50000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Extract relevant fields from the channel and feeds
output = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field2'],
    "humidity": data['feeds'][0]['field1'],
    "location": data['channel']['location'],
    # Add other fields as null if not present in the input JSON
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1828719.json", "w") as f:
    json.dump(output, f, indent=4)
