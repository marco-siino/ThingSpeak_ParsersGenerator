
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1274626,
        "name": "ardu",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temp",
        "field2": "hum",
        "created_at": "2020-12-30T17:16:25Z",
        "updated_at": "2020-12-31T15:18:29Z",
        "last_entry_id": 3157
    },
    "feeds": [
        {
            "created_at": "2021-01-10T23:51:22Z",
            "entry_id": 3157,
            "field1": "22.00",
            "field2": "36.00"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Extract relevant data from JSON text
temperature = data['feeds'][0]['field1']
humidity = data['feeds'][0]['field2']

# Create output JSON with schema structure
output_json = {
    "id": data['channel']['id'],
    "temperature": temperature,
    "humidity": humidity,
    "location": data['channel']['location'],
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1274626.json", "w") as f:
    json.dump(output_json, f, indent=4)
