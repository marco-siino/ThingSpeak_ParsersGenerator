
import json

def merge_location(data):
    if 'latitude' in data and 'longitude' in data:
        data['location'] = f"{data['latitude']}, {data['longitude']}"
        del data['latitude']
        del data['longitude']
    return data

def write_to_file(output_file, data):
    with open(output_file, 'w') as f:
        json.dump(data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 341114,
        "name": "humidity",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "created_at": "2017-10-05T05:10:35Z",
        "updated_at": "2017-10-27T21:10:11Z",
        "last_entry_id": 141
    },
    "feeds": [
        {
            "created_at": "2017-10-27T21:10:11Z",
            "entry_id": 141,
            "field1": "51"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge location field
data = merge_location(data['channel'])

# Create output JSON
output_data = {
    "id": data['channel']['id'],
    "temperature": None,
    "humidity": data['channel']['field1'],
    "pressure": None,
    "light": None,
    "air_quality": None,
    "location": data['channel']['location'],
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Add feeds data
output_data['feeds'] = [feed for feed in data['feeds'] if feed['field1'] != 'null']

# Write output JSON to file
write_to_file("thingspeak/output_json/mistral/341114.json", output_data)
