
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 769529,
        "name": "DHT11",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Humedad",
        "created_at": "2019-04-29T09:20:57Z",
        "updated_at": "2019-05-01T11:27:27Z",
        "last_entry_id": 4588
    },
    "feeds": [
        {
            "created_at": "2019-05-03T10:23:47Z",
            "entry_id": 4588,
            "field1": "25.10",
            "field2": "95.00    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Extract fields from data
output = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field1'],
    "humidity": data['feeds'][0]['field2'],
    "location": data['location'],
    # Add other fields as null if not present in the JSON text
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output to a file
with open("thingspeak/output_json/mistral/769529.json", "w") as f:
    json.dump(output, f, indent=4)
