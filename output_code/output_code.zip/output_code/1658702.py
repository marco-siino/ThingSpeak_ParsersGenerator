
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1658702,
        "name": "IoT Workshop - 1",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2022-02-20T05:30:42Z",
        "updated_at": "2022-02-20T05:45:22Z",
        "last_entry_id": 266
    },
    "feeds": [
        {
            "created_at": "2022-02-20T07:41:17Z",
            "entry_id": 266,
            "field1": "30.20",
            "field2": "49.00    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Initialize output JSON
output = {}
output['id'] = data['channel']['id']
output['temperature'] = data['channel']['feeds'][0]['field1']
output['humidity'] = data['channel']['feeds'][0]['field2']

# Fill other fields with null values
output['pressure'] = None
output['light'] = None
output['air_quality'] = None
output['soil_moisture'] = None
output['hardware'] = None
output['distance'] = None
output['ph'] = None

# Write output JSON to file
with open('thingspeak/output_json/mistral/1658702.json', 'w') as f:
    json.dump(output, f, indent=4)
