
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1255628,
        "name": "Giselda Richter DSB Wifi 121/1255628",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2020-12-11T16:45:05Z",
        "updated_at": "2020-12-14T13:04:11Z",
        "last_entry_id": 42
    },
    "feeds": [
        {
            "created_at": "2021-05-26T20:50:42Z",
            "entry_id": 42,
            "field1": "6.25000",
            "field2": "6.25000",
            "field3": "22.31250"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant data from JSON text
output = {
    "id": data["channel"]["id"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    "temperature": data["feeds"][0]["field1"],
    "humidity": None,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1255628.json", "w") as f:
    json.dump(output, f, indent=4)
