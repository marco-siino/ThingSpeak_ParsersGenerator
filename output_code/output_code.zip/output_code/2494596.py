
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2494596,
        "name": "LED ON_OFF",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "led1",
        "created_at": "2024-04-02T11:10:58Z",
        "updated_at": "2024-04-02T11:22:49Z",
        "last_entry_id": 2
    },
    "feeds": [
        {
            "created_at": "2024-04-02T11:27:12Z",
            "entry_id": 2,
            "field1": "1"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields based on the semantic of the JSON text
if "feeds" in data:
    feed = data["feeds"][0]
    if "field1" in feed:
        output_data["light"] = feed["field1"]

# Write output JSON to a file
with open("thingspeak/output_json/mistral/2494596.json", "w") as f:
    json.dump(output_data, f, indent=4)
