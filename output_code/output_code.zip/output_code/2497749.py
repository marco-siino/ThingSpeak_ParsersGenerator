
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2497749,
        "name": "vaulog",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "LED",
        "field2": "LED",
        "created_at": "2024-04-05T04:37:11Z",
        "updated_at": "2024-04-05T04:48:03Z",
        "last_entry_id": 8
    },
    "feeds": [
        {
            "created_at": "2024-04-05T04:53:42Z",
            "entry_id": 8,
            "field1": null,
            "field2": "50000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["light"] = data["channel"]["field1"]
output_data["hardware"] = data["channel"]["name"]
output_data["feeds"] = []

# Process feeds
for feed in data["feeds"]:
    feed_data = {}
    feed_data["created_at"] = feed["created_at"]
    feed_data["entry_id"] = feed["entry_id"]
    if feed["field2"] is not None:
        feed_data["light"] = feed["field2"]
    output_data["feeds"].append(feed_data)

# Write output JSON to file
with open("thingspeak/output_json/mistral/2497749.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
