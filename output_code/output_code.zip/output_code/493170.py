
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 493170,
        "name": "DHT11 temp sensor",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "humidity",
        "field2": "temperature",
        "created_at": "2018-05-10T20:49:24Z",
        "updated_at": "2018-09-20T20:35:57Z",
        "last_entry_id": 1211220
    },
    "feeds": [
        {
            "created_at": "2019-01-27T16:15:10Z",
            "entry_id": 1211220,
            "field1": "45.00000",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Create output JSON with schema structure
output_data = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0].get('field2', None),
    "humidity": data['feeds'][0].get('field1', None),
    "location": data['channel']['location'],
    # Add other fields with None values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/493170.json", "w") as f:
    json.dump(output_data, f, indent=4)
