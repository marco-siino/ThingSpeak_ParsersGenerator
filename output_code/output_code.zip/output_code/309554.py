
import json

def merge_location(data):
    if data["channel"]["latitude"] and data["channel"]["longitude"]:
        data["channel"]["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"
        del data['channel']['latitude']
        del data['channel']['longitude']
    return data

def write_output_json(data, filename):
    output_data = {}
    for key, value in data['channel'].items():
        if value is not None:
            output_data[key] = value
    for field in data['schema']['properties']:
        if field not in output_data:
            output_data[field] = None
    with open(filename, 'w') as f:
        json.dump(output_data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 309554,
        "name": "push",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temp",
        "created_at": "2017-07-30T06:05:32Z",
        "updated_at": "2017-07-30T06:50:28Z",
        "last_entry_id": 9
    },
    "feeds": [
        {
            "created_at": "2017-07-30T06:49:24Z",
            "entry_id": 9,
            "field1": "80"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Merge location field
data = merge_location(data)

# Write output JSON
write_output_json(data, "thingspeak/output_json/mistral/309554.json")
