
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1099403,
        "name": " environmental monitoring and weather prediction ",
        "latitude": "16.2379",
        "longitude": "80.6444",
        "field1": "temperature",
        "field2": "humidity",
        "field3": "pressure",
        "created_at": "2020-07-15T05:10:01Z",
        "updated_at": "2020-11-05T16:11:26Z",
        "last_entry_id": 22
    },
    "feeds": [
        {
            "created_at": "2020-11-05T16:12:29Z",
            "entry_id": 22,
            "field1": "179",
            "field2": "10.3",
            "field3": "215.1077407068753"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output_json = {}
output_json['id'] = data['channel']['id']
output_json['temperature'] = data['channel']['field1'] if data['channel']['field1'] else None
output_json['humidity'] = data['channel']['field2'] if data['channel']['field2'] else None
output_json['pressure'] = data['channel']['field3'] if data['channel']['field3'] else None
output_json['location'] = data['channel']['location']
output_json['air_quality'] = None
output_json['soil_moisture'] = None
output_json['hardware'] = None
output_json['distance'] = None
output_json['ph'] = None

# Add feeds to output JSON
for feed in data['feeds']:
    feed_data = {}
    feed_data['created_at'] = feed['created_at']
    feed_data['entry_id'] = feed['entry_id']
    feed_data['temperature'] = feed['field1'] if 'field1' in feed else None
    feed_data['humidity'] = feed['field2'] if 'field2' in feed else None
    feed_data['pressure'] = feed['field3'] if 'field3' in feed else None
    output_json['feeds'].append(feed_data)

# Write output JSON to file
with open('thingspeak/output_json/mistral/1099403.json', 'w') as f:
    json.dump(output_json, f, indent=4)
