
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2031981,
        "name": "DSB WIFI NXT25/2031981",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2023-02-13T11:59:39Z",
        "updated_at": "2023-02-14T13:45:34Z",
        "last_entry_id": 110025
    },
    "feeds": [
        {
            "created_at": "2024-07-22T07:58:33Z",
            "entry_id": 110025,
            "field1": "-6.06250",
            "field2": "-10.18750",
            "field3": "0.00000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract necessary data from JSON text
channel = data['channel']
feed = data['feeds'][0]

# Merge latitude and longitude into location
location = f"{channel['latitude']}, {channel['longitude']}"

# Create output JSON
output = {
    "id": channel['id'],
    "temperature": feed['field1'],
    "humidity": feed['field2'],
    "pressure": feed['field3'],
    "location": location,
    # Add other fields with null values if not present in the JSON text
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/2031981.json", "w") as f:
    json.dump(output, f, indent=4)
