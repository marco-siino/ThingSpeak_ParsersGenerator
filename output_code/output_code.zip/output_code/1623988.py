
import json

def merge_coordinates(latitude, longitude):
    if latitude and longitude:
        return f"{latitude}, {longitude}"
    return None

def convert_json(json_text, schema):
    data = json.loads(json_text)

    output = {}
    for key, value in schema["properties"].items():
        if key in data:
            output[key] = data[key]
        else:
            output[key] = None

    # Merge latitude and longitude into location
    if "location" in schema["properties"]:
        output["location"] = merge_coordinates(data["channel"]["latitude"], data["channel"]["longitude"])

    return json.dumps(output, indent=4)

json_text = """
{
    "channel": {
        "id": 1623988,
        "name": "Senson1",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "created_at": "2022-01-03T08:50:23Z",
        "updated_at": "2022-01-03T08:56:49Z",
        "last_entry_id": 24
    },
    "feeds": [
        {
            "created_at": "2022-01-10T06:38:47Z",
            "entry_id": 24,
            "field1": "67   "
        }
    ]
}
"""

schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

output_json = convert_json(json_text, json.loads(schema))
with open("thingspeak/output_json/mistral/1623988.json", "w") as f:
    f.write(output_json)
