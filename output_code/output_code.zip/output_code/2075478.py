
import json

# Input JSON text
input_json = """
{
    "channel": {
        "id": 2075478,
        "name": "HumidityTest",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "humidity",
        "created_at": "2023-03-22T01:20:19Z",
        "updated_at": "2023-05-24T01:29:05Z",
        "last_entry_id": 25
    },
    "feeds": [
        {
            "created_at": "2023-05-31T01:39:13Z",
            "entry_id": 25,
            "field1": "1"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Load input JSON
data = json.loads(input_json)

# Merge latitude and longitude into location
data['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Remove unnecessary fields
data.pop('channel', None)
data['feeds'][0].pop('created_at', None)

# Initialize output JSON with schema properties
output_json = {}
for key in json.loads(schema)['properties']:
    output_json[key] = None

# Fill output JSON with data
for key in data:
    if key in output_json:
        output_json[key] = data[key]

# Write output JSON to file
with open('thingspeak/output_json/mistral/2075478.json', 'w') as f:
    json.dump(output_json, f, indent=4)
