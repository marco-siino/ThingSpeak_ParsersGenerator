
import json

def merge_location(data):
    if data["channel"]["latitude"] and data["channel"]["longitude"]:
        data["channel"]["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"
        del data['channel']['latitude']
        del data['channel']['longitude']
    return data

def write_to_file(data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 610990,
        "name": "CO2",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "CO2",
        "created_at": "2018-10-26T06:20:53Z",
        "updated_at": "2018-10-26T06:20:53Z",
        "last_entry_id": 112
    },
    "feeds": [
        {
            "created_at": "2018-12-07T05:50:12Z",
            "entry_id": 112,
            "field1": "5"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)
data = merge_location(data)

# Create output JSON structure based on the schema
output_data = {
    "id": data["channel"]["id"],
    "location": data["channel"]["location"] if data["channel"]["location"] else "null",
    # Add other fields based on the semantic of the JSON text
    "temperature": data["channel"]["field1"] if data["channel"]["field1"] else "null",
    "humidity": "null",
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Add feeds to the output data
output_data["feeds"] = data["feeds"]

# Write output JSON to a file
write_to_file(output_data, "thingspeak/output_json/mistral/610990.json")
