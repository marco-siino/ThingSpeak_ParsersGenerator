
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1818755,
        "name": "Test Environment Sensors",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Pressure",
        "field3": "Humidity",
        "created_at": "2022-08-02T06:08:28Z",
        "updated_at": "2022-08-02T06:45:46Z",
        "last_entry_id": 243
    },
    "feeds": [
        {
            "created_at": "2022-08-02T08:47:10Z",
            "entry_id": 243,
            "field1": "23.31503",
            "field2": "100537.2",
            "field3": "58.59617"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
json_data = json.loads(json_text)
json_schema_data = json.loads(json_schema)

# Extract relevant data from JSON text
channel = json_data["channel"]
feed = json_data["feeds"][0]
location = f"{channel['latitude']}, {channel['longitude']}"

# Create output JSON data
output_data = {
    "id": channel["id"],
    "temperature": feed["field1"],
    "humidity": feed["field3"],
    "pressure": feed["field2"],
    "location": location,
    # Add other fields with null values if not present in the JSON text
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1818755.json", "w") as f:
    json.dump(output_data, f, indent=4)
