
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1635770,
        "name": "KUALITAS UDARA DALAM RUANG RAPAT",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "CO2",
        "created_at": "2022-01-19T12:59:12Z",
        "updated_at": "2022-01-19T13:30:01Z",
        "last_entry_id": 206
    },
    "feeds": [
        {
            "created_at": "2022-02-13T12:09:12Z",
            "entry_id": 206,
            "field1": "2.48    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["air_quality"] = data["channel"]["field1"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields with values from the JSON text if available
for key in schema["properties"]:
    if key in data["channel"]:
        output_data[key] = data["channel"][key]

# Write output JSON to file
with open("thingspeak/output_json/mistral/1635770.json", "w") as f:
    json.dump(output_data, f, indent=4)
