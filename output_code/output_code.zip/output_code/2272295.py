
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2272295,
        "name": "nombre_canal",
        "description": "para que sirve el canal  y los campos son los receptores de informacion",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Humedad",
        "created_at": "2023-09-16T00:07:23Z",
        "updated_at": "2023-09-16T00:09:38Z",
        "last_entry_id": 79
    },
    "feeds": [
        {
            "created_at": "2023-09-16T01:50:26Z",
            "entry_id": 79,
            "field1": "29.80000",
            "field2": "59.00000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = data["feeds"][0]["field2"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Write output JSON to file
with open("thingspeak/output_json/mistral/2272295.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
