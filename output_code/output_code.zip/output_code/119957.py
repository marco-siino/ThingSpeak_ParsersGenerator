
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 119957,
        "name": "ESP8266 DHT22",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatur",
        "field2": "Luftfeuchtigkeit",
        "field3": "Temperatur",
        "field4": "Voltage",
        "created_at": "2016-05-27T17:56:38Z",
        "updated_at": "2018-06-26T15:52:47Z",
        "last_entry_id": 56027
    },
    "feeds": [
        {
            "created_at": "2018-11-19T13:10:10Z",
            "entry_id": 56027,
            "field1": "22.70000",
            "field2": "22.00000",
            "field3": null,
            "field4": "3.19600"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the channel object
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields as empty strings if they don't exist in the JSON text
    "pressure": "",
    "light": "",
    "air_quality": "",
    "soil_moisture": "",
    "hardware": "",
    "distance": "",
    "ph": ""
}

# Write output JSON to a file
with open("thingspeak/output_json/mistral/119957.json", "w") as f:
    json.dump(output, f, indent=4)
