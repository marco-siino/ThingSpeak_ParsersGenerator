
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 216910,
        "name": "dsa",
        "latitude": "17.6805",
        "longitude": "74.0183",
        "field1": "Voltage",
        "created_at": "2017-01-20T12:59:55Z",
        "updated_at": "2017-03-05T13:31:27Z",
        "last_entry_id": 1409
    },
    "feeds": [
        {
            "created_at": "2017-03-05T13:31:27Z",
            "entry_id": 1409,
            "field1": "1911"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields based on the semantic of the JSON text
if "field1" in data["channel"]:
    output_data["field1"] = data["channel"]["field1"]

# Write output JSON to a file
with open("thingspeak/output_json/mistral/216910.json", "w") as f:
    json.dump(output_data, f, indent=4)
