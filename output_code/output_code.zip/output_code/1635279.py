
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1635279,
        "name": "DSB WIFI SYS40/1635279",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2022-01-18T19:03:53Z",
        "updated_at": "2022-01-18T19:05:43Z",
        "last_entry_id": 1682
    },
    "feeds": [
        {
            "created_at": "2022-01-24T15:11:32Z",
            "entry_id": 1682,
            "field1": "26.56250",
            "field2": "25.06250",
            "field3": "29.87500"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the "channel" object
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["field1"],
    "humidity": None,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Extract relevant fields from the first feed in the "feeds" array
feed = data["feeds"][0]
output["temperature"] = feed["field1"]
output["humidity"] = feed["field2"]
output["pressure"] = feed["field3"]

# Write output JSON to file
with open("thingspeak/output_json/mistral/1635279.json", "w") as f:
    json.dump(output, f, indent=4)
