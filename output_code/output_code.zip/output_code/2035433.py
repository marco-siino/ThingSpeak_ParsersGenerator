
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2035433,
        "name": "DevOps",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": null,
        "created_at": "2023-02-16T06:05:22Z",
        "updated_at": "2023-02-16T08:32:38Z",
        "last_entry_id": 6
    },
    "feeds": [
        {
            "created_at": "2023-02-16T09:58:20Z",
            "entry_id": 6,
            "field1": "22.4",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Extract relevant fields from the JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["field1"],
    "humidity": None if data["channel"]["field2"] is None else data["channel"]["field2"],
    "location": data["channel"]["location"],
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None,
    "air_quality": None,
    "light": None
}

# Add feeds data to the output
for feed in data["feeds"]:
    if output["temperature"] is None:
        output["temperature"] = feed["field1"]
    if output["humidity"] is not None and output["humidity"] != feed["field2"]:
        output["humidity"] = "null"
    if feed["field1"] and feed["field2"] is None:
        output["air_quality"] = feed["field1"]

# Write output to a file
with open("thingspeak/output_json/mistral/2035433.json", "w") as f:
    json.dump(output, f, indent=4)
