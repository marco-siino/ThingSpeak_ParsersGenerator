
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 500575,
        "name": "AM3202",
        "description": "Testsetup ESP8266 with AM3202 Sensor",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatur",
        "field2": "Humidity",
        "created_at": "2018-05-20T15:46:42Z",
        "updated_at": "2018-12-16T14:45:27Z",
        "last_entry_id": 4428
    },
    "feeds": [
        {
            "created_at": "2019-01-28T14:46:50Z",
            "entry_id": 4428,
            "field1": "21.4",
            "field2": "52.6"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output data
output_data = {}
output_data['id'] = data['channel']['id']
output_data['temperature'] = data['feeds'][0]['field1']
output_data['humidity'] = data['feeds'][0]['field2']

# Fill other fields with null values
output_data['pressure'] = None
output_data['light'] = None
output_data['air_quality'] = None
output_data['soil_moisture'] = None
output_data['hardware'] = None
output_data['distance'] = None
output_data['ph'] = None

# Write output JSON to file
with open('thingspeak/output_json/mistral/500575.json', 'w') as f:
    json.dump(output_data, f, indent=4)
