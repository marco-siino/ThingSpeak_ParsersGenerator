
import json

# JSON text
data = """
{
    "channel": {
        "id": 907115,
        "name": "Probe1 ",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temp",
        "field2": "Humidity",
        "created_at": "2019-11-09T19:58:17Z",
        "updated_at": "2019-11-10T07:51:21Z",
        "last_entry_id": 6568
    },
    "feeds": [
        {
            "created_at": "2019-11-12T01:34:47Z",
            "entry_id": 6568,
            "field1": "23.00",
            "field2": "43.00"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
json_text = json.loads(data)
json_schema = json.loads(schema)

# Extract relevant data from JSON text
output = {
    "id": json_text["channel"]["id"],
    "temperature": json_text["feeds"][0]["field1"],
    "humidity": json_text["feeds"][0]["field2"],
    "location": f"{json_text['channel']['latitude']}, {json_text['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/907115.json", "w") as f:
    json.dump(output, f, indent=4)
