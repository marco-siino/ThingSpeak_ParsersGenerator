
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1713443,
        "name": "progetto laboratorio TD2_2022",
        "description": "progetto del laboratorio TD2_2022 Sanelli Francesca",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temp",
        "field2": "Humidity",
        "created_at": "2022-04-24T17:13:20Z",
        "updated_at": "2022-05-10T17:22:35Z",
        "last_entry_id": 28
    },
    "feeds": [
        {
            "created_at": "2022-06-09T15:45:58Z",
            "entry_id": 28,
            "field1": "27.379999999999995",
            "field2": "36"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output data with schema properties
output_data = {
    "id": data['channel']['id'],
    "temperature": None,
    "humidity": None,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "location": data['channel']['location'],
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Fill output data with values from feeds
for feed in data['feeds']:
    output_data['temperature'] = feed['field1']
    output_data['humidity'] = feed['field2']

# Write output JSON to file
with open("thingspeak/output_json/mistral/1713443.json", "w") as f:
    json.dump(output_data, f, indent=4)
