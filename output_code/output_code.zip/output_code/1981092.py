
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1981092,
        "name": "Temperature",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2022-12-14T09:00:37Z",
        "updated_at": "2022-12-14T09:01:02Z",
        "last_entry_id": 6
    },
    "feeds": [
        {
            "created_at": "2022-12-15T09:30:57Z",
            "entry_id": 6,
            "field1": "45",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["channel"]["field1"]
output_data["humidity"] = data["channel"]["field2"] if data["channel"]["field2"] else None
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields with values from feeds if available
for feed in data["feeds"]:
    if feed["field1"]:
        if output_data["temperature"] == feed["field1"]:
            continue
        else:
            output_data["temperature"] = feed["field1"]
    if feed["field2"]:
        if output_data["humidity"] == feed["field2"]:
            continue
        else:
            output_data["humidity"] = feed["field2"]

# Write output JSON to file
with open("thingspeak/output_json/mistral/1981092.json", "w") as f:
    json.dump(output_data, f, indent=4)
