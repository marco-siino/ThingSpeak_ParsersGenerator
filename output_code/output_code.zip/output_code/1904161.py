
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1904161,
        "name": "Arduino_iot_sonar",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Distance",
        "created_at": "2022-10-21T18:28:56Z",
        "updated_at": "2022-10-21T18:29:13Z",
        "last_entry_id": 54
    },
    "feeds": [
        {
            "created_at": "2023-03-15T16:38:36Z",
            "entry_id": 54,
            "field1": "36.83849"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output JSON
output = {}
output["id"] = data["channel"]["id"]
output["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output["distance"] = data["feeds"][0]["field1"]

# Fill other fields if present in the JSON text
for key in schema["properties"]:
    if key in data["channel"]:
        output[key] = data["channel"][key]

# Write output JSON to file
with open("thingspeak/output_json/mistral/1904161.json", "w") as f:
    json.dump(output, f, indent=4)
