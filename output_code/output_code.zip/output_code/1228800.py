
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1228800,
        "name": "coviduino",
        "description": "Arduino Air Quality",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "CO2",
        "field2": "Temperature",
        "field3": "Humidity",
        "created_at": "2020-11-13T17:35:11Z",
        "updated_at": "2020-11-23T08:34:40Z",
        "last_entry_id": 107
    },
    "feeds": [
        {
            "created_at": "2020-11-23T13:14:44Z",
            "entry_id": 107,
            "field1": "0.00000",
            "field2": "25.49401",
            "field3": "41.48560"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the JSON text
output_data = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field2"],
    "humidity": data["feeds"][0]["field3"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields as empty strings or null if not present in the JSON text
    "pressure": "",
    "light": "",
    "air_quality": "",
    "soil_moisture": "",
    "hardware": "",
    "distance": "",
    "ph": ""
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1228800.json", "w") as f:
    json.dump(output_data, f, indent=4)
