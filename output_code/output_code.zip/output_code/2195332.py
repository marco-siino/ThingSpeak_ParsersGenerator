
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2195332,
        "name": "iot test",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temp",
        "field2": "light",
        "field3": "co2",
        "created_at": "2023-06-20T03:12:24Z",
        "updated_at": "2023-06-20T03:48:44Z",
        "last_entry_id": 98
    },
    "feeds": [
        {
            "created_at": "2023-06-20T04:23:45Z",
            "entry_id": 98,
            "field1": "24",
            "field2": "969",
            "field3": "465"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields based on the semantic of the JSON text
output_data["temperature"] = data["channel"]["field1"]
output_data["light"] = data["channel"]["field2"]
output_data["air_quality"] = data["channel"]["field3"]

# If feeds exist, fill other fields
if len(data["feeds"]) > 0:
    feed = data["feeds"][0]
    output_data["humidity"] = "null"  # Replace this with the actual value if available
    output_data["pressure"] = "null"  # Replace this with the actual value if available
    output_data["soil_moisture"] = "null"  # Replace this with the actual value if available
    output_data["hardware"] = "null"  # Replace this with the actual value if available
    output_data["distance"] = "null"  # Replace this with the actual value if available
    output_data["ph"] = "null"  # Replace this with the actual value if available

    # Fill feeds field in the output data
    feeds = []
    feeds.append({
        "created_at": feed["created_at"],
        "entry_id": feed["entry_id"],
        "temperature": feed["field1"],
        "humidity": "null",  # Replace this with the actual value if available
        "pressure": "null",  # Replace this with the actual value if available
        "light": feed["field2"],
        "air_quality": feed["field3"],
        "soil_moisture": "null",  # Replace this with the actual value if available
        "hardware": "null",  # Replace this with the actual value if available
        "distance": "null",  # Replace this with the actual value if available
        "ph": "null"  # Replace this with the actual value if available
    })
    output_data["feeds"] = feeds

# Write the output JSON to a file
with open("thingspeak/output_json/mistral/2195332.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
