
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1146869,
        "name": "muh fadhil",
        "description": "holla",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "field2": "Temperature",
        "created_at": "2020-09-16T07:33:10Z",
        "updated_at": "2020-09-16T07:38:04Z",
        "last_entry_id": 6
    },
    "feeds": [
        {
            "created_at": "2020-09-16T07:39:21Z",
            "entry_id": 6,
            "field1": "32.90",
            "field2": "66.00    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Initialize output data with schema properties
output_data = {
    "id": data['channel']['id'],
    "temperature": None,
    "humidity": None,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "location": data['channel']['location'],
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Fill output data from feeds
for feed in data['feeds']:
    output_data['temperature'] = feed['field2']
    output_data['humidity'] = feed['field1']

# Write output JSON to file
with open("thingspeak/output_json/mistral/1146869.json", "w") as f:
    json.dump(output_data, f, indent=4)
