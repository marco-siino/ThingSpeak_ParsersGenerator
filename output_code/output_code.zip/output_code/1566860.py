
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1566860,
        "name": "IESB - Projeto Integrador I",
        "description": "Coletando dados do ESP8266 + DHT11 para medir e analisar temperatura e umidade",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Umidade",
        "created_at": "2021-11-11T00:32:59Z",
        "updated_at": "2021-12-17T17:15:21Z",
        "last_entry_id": 14715
    },
    "feeds": [
        {
            "created_at": "2021-12-17T17:46:34Z",
            "entry_id": 14715,
            "field1": "27.20",
            "field2": "59.00    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output JSON
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the input JSON
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1566860.json", "w") as f:
    json.dump(output, f, indent=4)
