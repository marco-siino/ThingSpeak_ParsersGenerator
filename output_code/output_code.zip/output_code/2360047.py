
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2360047,
        "name": "Smart Floral Composter",
        "description": "The process involves collecting floral waste, transporting it to manufacturing units, using smart   composters with IoT technology to convert the waste into nutrient-rich manure, and distributing the   manure to support healthy plant growth. This system e",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2023-11-27T09:41:51Z",
        "updated_at": "2023-12-02T11:30:46Z",
        "last_entry_id": 95
    },
    "feeds": [
        {
            "created_at": "2023-12-07T10:25:21Z",
            "entry_id": 95,
            "field1": "28.00",
            "field2": "59.00    "
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["feeds"][0]["field1"],
    "humidity": data["channel"]["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields if they exist in the JSON text
    # ...
}

# Write output to file
with open("thingspeak/output_json/mistral/2360047.json", "w") as f:
    json.dump(output, f, indent=4)
