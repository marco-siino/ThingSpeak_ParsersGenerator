
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2270186,
        "name": "LED Blinking",
        "description": "LED Blinking Using Node MCU",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "led1",
        "field2": "led2",
        "field3": "led3",
        "created_at": "2023-09-14T05:50:02Z",
        "updated_at": "2023-09-14T07:44:59Z",
        "last_entry_id": 36
    },
    "feeds": [
        {
            "created_at": "2023-10-30T05:14:46Z",
            "entry_id": 36,
            "field1": "1",
            "field2": "1",
            "field3": "1"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data["channel"]["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output data
output_data = {
    "id": data["channel"]["id"],
    "location": data["channel"]["location"],
}

# Iterate through the schema properties and fill the output data
for key, value in json.loads(schema)["properties"].items():
    if key in data["channel"]:
        output_data[key] = data["channel"][key]

# Write output JSON to file
with open("thingspeak/output_json/mistral/2270186.json", "w") as f:
    json.dump(output_data, f, indent=4)
