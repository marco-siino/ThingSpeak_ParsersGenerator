
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1552839,
        "name": "environment",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2021-10-29T01:41:44Z",
        "updated_at": "2021-10-29T06:20:19Z",
        "last_entry_id": 17
    },
    "feeds": [
        {
            "created_at": "2021-10-29T06:24:15Z",
            "entry_id": 17,
            "field1": "30.89",
            "field2": "43.2"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant fields from JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["field1"],
    "humidity": data["channel"]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields from the schema if they exist in the JSON text
    # ...
}

# Process feeds
feeds = data["feeds"]
feed_data = []
for feed in feeds:
    feed_data.append({
        "created_at": feed["created_at"],
        "entry_id": feed["entry_id"],
        "temperature": feed.get("field1", "null"),
        "humidity": feed.get("field2", "null"),
        # Add other fields from the schema if they exist in the feed
        # ...
    })
output["feeds"] = feed_data

# Write output to file
with open("thingspeak/output_json/mistral/1552839.json", "w") as f:
    json.dump(output, f, indent=4)
