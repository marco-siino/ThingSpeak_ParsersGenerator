
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 432010,
        "name": "rypansi",
        "description": "pollution",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "co2",
        "created_at": "2018-02-21T15:40:47Z",
        "updated_at": "2018-03-07T05:11:34Z",
        "last_entry_id": 104
    },
    "feeds": [
        {
            "created_at": "2018-03-07T05:11:34Z",
            "entry_id": 104,
            "field1": "0210"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["air_quality"] = data["channel"]["field1"]
location = data["channel"]["latitude"] + "," + data["channel"]["longitude"]
output_data["location"] = location if location else None
output_data["temperature"] = None
output_data["humidity"] = None
output_data["pressure"] = None
output_data["light"] = None
output_data["soil_moisture"] = None
output_data["hardware"] = None
output_data["distance"] = None
output_data["ph"] = None

# Prepare output feeds
feeds = data["feeds"]
output_feeds = []
for feed in feeds:
    output_feed = {}
    output_feed["entry_id"] = feed["entry_id"]
    output_feed["air_quality"] = feed["field1"]
    output_feeds.append(output_feed)

# Combine output data and output feeds
output_data["feeds"] = output_feeds

# Write output JSON into a file
with open("thingspeak/output_json/mistral/432010.json", "w") as f:
    json.dump(output_data, f, indent=4)
