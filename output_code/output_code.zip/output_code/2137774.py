
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2137774,
        "name": "WEATHER STATION",
        "description": "To check the air quality in the environment",
        "latitude": "13.0827",
        "longitude": "80.2707",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2023-05-08T10:40:52Z",
        "updated_at": "2023-07-17T11:19:53Z",
        "last_entry_id": 101
    },
    "feeds": [
        {
            "created_at": "2023-07-17T11:27:00Z",
            "entry_id": 101,
            "field1": "72.8",
            "field2": "95"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["feeds"][0]["field1"],
    "humidity": data["channel"]["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/2137774.json", "w") as f:
    json.dump(output_data, f, indent=4)
