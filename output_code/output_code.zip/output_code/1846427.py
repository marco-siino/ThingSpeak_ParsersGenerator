
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1846427,
        "name": "DSB WIFI SSI05/1846427",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2022-08-31T18:29:10Z",
        "updated_at": "2022-08-31T18:42:15Z",
        "last_entry_id": 347621
    },
    "feeds": [
        {
            "created_at": "2024-07-21T20:35:49Z",
            "entry_id": 347621,
            "field1": "-16.93750",
            "field2": "-22.00000",
            "field3": "8.31250"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema_data = json.loads(schema)

# Extract relevant data from JSON text
channel = data["channel"]
feed = data["feeds"][0]
location = f"{channel['latitude']}, {channel['longitude']}"
temperature = feed["field1"]
humidity = None
pressure = None
light = None
air_quality = None
soil_moisture = None
hardware = None
distance = None
ph = None

# Create output JSON
output_data = {
    "id": channel["id"],
    "temperature": temperature,
    "humidity": humidity,
    "pressure": pressure,
    "light": light,
    "air_quality": air_quality,
    "location": location,
    "soil_moisture": soil_moisture,
    "hardware": hardware,
    "distance": distance,
    "ph": ph
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1846427.json", "w") as f:
    json.dump(output_data, f, indent=4)
