
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 456744,
        "name": "TestChannel",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Pressure",
        "created_at": "2018-03-23T04:47:43Z",
        "updated_at": "2018-03-23T06:23:14Z",
        "last_entry_id": 37
    },
    "feeds": [
        {
            "created_at": "2018-03-23T06:23:15Z",
            "entry_id": 37,
            "field1": "32.02573776245117",
            "field2": "38.905120849609375",
            "field3": "1011.188232421875"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant data from JSON text
channel = data['channel']
feed = data['feeds'][0]
location = f"{channel['latitude']}, {channel['longitude']}"
temperature = feed['field1']
humidity = feed['field2']
pressure = feed['field3']

# Create output JSON with schema structure
output = {
    "id": channel['id'],
    "temperature": temperature,
    "humidity": humidity,
    "pressure": pressure,
    "location": location,
    # Add other fields with null values if not present in the JSON text
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/456744.json", "w") as f:
    json.dump(output, f, indent=4)
