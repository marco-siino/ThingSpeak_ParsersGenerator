
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 553104,
        "name": "first",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2018-08-03T09:08:31Z",
        "updated_at": "2018-08-04T10:39:00Z",
        "last_entry_id": 57
    },
    "feeds": [
        {
            "created_at": "2018-08-04T10:39:00Z",
            "entry_id": 57,
            "field1": "26.39",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["channel"]["field1"]
output_data["humidity"] = data["channel"]["field2"]

# Merge latitude and longitude into location
location = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["location"] = location

# Fill other fields with values from feeds if available
feed = data["feeds"][0]
if feed["field1"] is not None:
    output_data["pressure"] = feed["field1"]
if feed["field2"] is not None:
    output_data["light"] = feed["field2"]

# Write output JSON to file
with open("thingspeak/output_json/mistral/553104.json", "w") as f:
    json.dump(output_data, f, indent=4)
