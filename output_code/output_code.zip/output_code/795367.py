
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 795367,
        "name": "Basic",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "PM10",
        "field2": "PM2.5",
        "field3": "Temperature",
        "field4": "Humidity",
        "created_at": "2019-06-05T18:47:43Z",
        "updated_at": "2019-06-05T20:08:03Z",
        "last_entry_id": 614
    },
    "feeds": [
        {
            "created_at": "2019-06-06T19:24:09Z",
            "entry_id": 614,
            "field1": "56.06",
            "field2": "14.89",
            "field3": null,
            "field4": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0].get("field3", "null"),
    "humidity": data["feeds"][0].get("field4", "null"),
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields as they are in the schema, but leave them as 'null' if not present in the JSON text
    "pressure": "null",
    "light": "null",
    "air_quality": data["channel"]["field1"],
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output JSON to a file
with open("thingspeak/output_json/mistral/795367.json", "w") as f:
    json.dump(output_data, f, indent=4)
