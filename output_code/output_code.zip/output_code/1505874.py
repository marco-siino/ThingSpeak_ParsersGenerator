
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1505874,
        "name": "Esw lab3",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2021-09-14T16:23:18Z",
        "updated_at": "2021-09-14T17:46:44Z",
        "last_entry_id": 200
    },
    "feeds": [
        {
            "created_at": "2021-09-14T13:26:35Z",
            "entry_id": 100,
            "field1": "27.7",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"
output_data["temperature"] = data["channel"]["field1"]
output_data["humidity"] = data["channel"]["field2"]

# Process feeds
for feed in data["feeds"]:
    entry = {}
    entry["created_at"] = feed["created_at"]
    entry["temperature"] = feed["field1"]
    entry["humidity"] = feed["field2"]
    output_data["feeds"] = [entry]

# Write output JSON to file
with open("thingspeak/output_json/mistral/1505874.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
