
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 295983,
        "name": "Server\u00fcberwachung Ortenleite 21",
        "description": "\u00dcberwachung Serverraum (Hauswirtschaftsraums) mit DHT 22 Sensor an Rasperry Pi, der auch als openvpn gateway dient",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatur",
        "field2": "Luftfeuchtigkeit",
        "created_at": "2017-07-01T15:30:00Z",
        "updated_at": "2019-07-10T07:32:52Z",
        "last_entry_id": 290768
    },
    "feeds": [
        {
            "created_at": "2020-04-11T07:55:10Z",
            "entry_id": 290768,
            "field1": "24.40",
            "field2": "37.70"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields as null if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/295983.json", "w") as f:
    json.dump(output, f, indent=4)
