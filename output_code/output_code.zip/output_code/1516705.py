
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1516705,
        "name": "CSE3006 LAB FAT - 19BCE1485",
        "description": "lab submission for tinkercad circuit",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "created_at": "2021-09-24T07:14:21Z",
        "updated_at": "2021-12-10T06:39:12Z",
        "last_entry_id": 18
    },
    "feeds": [
        {
            "created_at": "2021-12-27T13:29:01Z",
            "entry_id": 18,
            "field1": "24"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output = {}
output['id'] = data['channel']['id']
output['location'] = data['channel']['location']
output['temperature'] = data['channel']['field1'] if data['channel']['field1'] else None

# Iterate through feeds and add relevant fields to output JSON
for feed in data['feeds']:
    if feed['field1']:
        if output['temperature']:
            output['temperature'] += ', ' + feed['field1']
        else:
            output['temperature'] = feed['field1']

# Write output JSON to file
with open('thingspeak/output_json/mistral/1516705.json', 'w') as f:
    json.dump(output, f, indent=4)
