
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2167551,
        "name": "EWFD",
        "description": "Prototype 1",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "field3": "distance",
        "created_at": "2023-05-30T08:13:55Z",
        "updated_at": "2023-06-06T08:52:17Z",
        "last_entry_id": 109
    },
    "feeds": [
        {
            "created_at": "2023-06-08T08:22:57Z",
            "entry_id": 109,
            "field1": "24.21",
            "field2": "52.00",
            "field3": "19.68"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["channel"]["field1"]
output_data["humidity"] = data["channel"]["field2"]
output_data["distance"] = data["channel"]["field3"]
location = data["channel"]["latitude"] + "," + data["channel"]["longitude"]
output_data["location"] = location if location else None

feed = data["feeds"][0]
output_data["created_at"] = feed["created_at"]
output_data["entry_id"] = feed["entry_id"]

# Write output JSON to file
with open("thingspeak/output_json/mistral/2167551.json", "w") as f:
    json.dump(output_data, f, indent=4)
