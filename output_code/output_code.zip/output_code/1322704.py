
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1322704,
        "name": "weather IoT",
        "description": "temp",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "TEMPERATURE",
        "field2": "HUMIDITY",
        "created_at": "2021-03-09T05:40:24Z",
        "updated_at": "2021-03-09T08:37:00Z",
        "last_entry_id": 86
    },
    "feeds": [
        {
            "created_at": "2021-03-09T08:56:24Z",
            "entry_id": 86,
            "field1": "33.0",
            "field2": "68.0"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Initialize output JSON
output = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field1'],
    "humidity": data['feeds'][0]['field2'],
    "location": data['channel']['location'],
    # Add other fields with null values if not present in the input JSON
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1322704.json", "w") as f:
    json.dump(output, f, indent=4)
