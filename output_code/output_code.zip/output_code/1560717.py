
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1560717,
        "name": "\u6eab\u6ebc\u5ea6",
        "latitude": "24.797783",
        "longitude": "121.001735",
        "field1": "Humidity",
        "field2": "Temperature",
        "created_at": "2021-11-05T06:19:42Z",
        "updated_at": "2021-11-05T06:25:16Z",
        "last_entry_id": 121
    },
    "feeds": [
        {
            "created_at": "2021-12-24T06:02:41Z",
            "entry_id": 121,
            "field1": "21",
            "field2": "79"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant fields from JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field2"],
    "humidity": data["feeds"][0]["field1"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if they are present in the schema
    # ...
}

# Write output to file
with open("thingspeak/output_json/mistral/1560717.json", "w") as f:
    json.dump(output, f, indent=4)
