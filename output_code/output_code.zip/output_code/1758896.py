
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1758896,
        "name": "TempProbe",
        "description": "Temperature Probe",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "created_at": "2022-06-05T08:47:29Z",
        "updated_at": "2022-06-05T08:59:04Z",
        "last_entry_id": 16
    },
    "feeds": [
        {
            "created_at": "2022-06-05T09:04:21Z",
            "entry_id": 16,
            "field1": "34.00    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output data
output_data = {}
output_data['id'] = data['channel']['id']
output_data['temperature'] = data['channel']['feeds'][0]['field1']

# Fill other fields with null values
output_data['humidity'] = None
output_data['pressure'] = None
output_data['light'] = None
output_data['air_quality'] = None
output_data['soil_moisture'] = None
output_data['hardware'] = None
output_data['distance'] = None
output_data['ph'] = None

# Write output JSON to file
with open('thingspeak/output_json/mistral/1758896.json', 'w') as f:
    json.dump(output_data, f, indent=4)
