
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 744677,
        "name": "Room A",
        "description": "Indoor Temperature and Humidity from DHT11",
        "latitude": "9.912249",
        "longitude": "-84.027466",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2019-03-29T03:37:18Z",
        "updated_at": "2019-03-29T04:29:27Z",
        "elevation": "1200",
        "last_entry_id": 228040
    },
    "feeds": [
        {
            "created_at": "2019-12-09T01:58:47Z",
            "entry_id": 228040,
            "field1": "21.00",
            "field2": "47.00"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the "channel" object
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["feeds"][0]["field1"],
    "humidity": data["channel"]["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if they are not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/744677.json", "w") as f:
    json.dump(output, f, indent=4)
