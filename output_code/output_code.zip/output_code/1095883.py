
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1095883,
        "name": "myWSTData",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Light",
        "field4": "Atmosphere",
        "created_at": "2020-07-08T15:41:03Z",
        "updated_at": "2020-07-08T15:41:14Z",
        "last_entry_id": 401
    },
    "feeds": [
        {
            "created_at": "2020-07-13T13:02:13Z",
            "entry_id": 401,
            "field1": "27",
            "field2": "54",
            "field3": "0",
            "field4": "101352"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output_json = {}

# Extract fields from data and populate output_json
for key, value in data['channel'].items():
    if value is not None and value != "0.0":
        output_json[key] = value

for feed in data['feeds']:
    for key, value in feed.items():
        if value is not None:
            output_json[key] = value

# Write output JSON to file
with open("thingspeak/output_json/mistral/1095883.json", "w") as f:
    json.dump(output_json, f, indent=4)
