
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 491968,
        "name": "Channel 12",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "field2": "Temperature",
        "created_at": "2018-05-09T13:12:43Z",
        "updated_at": "2018-07-27T03:50:20Z",
        "last_entry_id": 207
    },
    "feeds": [
        {
            "created_at": "2022-05-20T04:13:21Z",
            "entry_id": 207,
            "field1": "59.099998474121094",
            "field2": "25.100000381469727"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant data from JSON text
channel = data["channel"]
feed = data["feeds"][0]
location = f"{channel['latitude']}, {channel['longitude']}"
temperature = feed["field2"]
humidity = feed["field1"]

# Create output JSON with schema structure
output = {
    "id": channel["id"],
    "temperature": temperature,
    "humidity": humidity,
    "location": location,
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/491968.json", "w") as f:
    json.dump(output, f, indent=4)
