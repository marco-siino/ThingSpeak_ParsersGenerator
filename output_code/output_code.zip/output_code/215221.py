
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 215221,
        "name": "Bernd",
        "description": "Sensor 1 .Eingang innen",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatur",
        "created_at": "2017-01-17T13:49:05Z",
        "updated_at": "2024-01-10T13:25:25Z",
        "last_entry_id": 7324628
    },
    "feeds": [
        {
            "created_at": "2024-01-10T06:43:47Z",
            "entry_id": 7324628,
            "field1": "14.50"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output data
output_data = {}

# Iterate through properties in the schema and fill the output data
for key, value in json.loads(json_schema)["properties"].items():
    if key in data['channel']:
        output_data[key] = data['channel'][key]

# Write output JSON to file
with open("thingspeak/output_json/mistral/215221.json", "w") as f:
    json.dump(output_data, f, indent=4)
