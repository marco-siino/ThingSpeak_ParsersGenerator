
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2010479,
        "name": "UAS IoT 02_Afandi Yusuf A_TOLI 5",
        "description": "Afandi Yusuf A | 2003411016 | TOLI 5",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2023-01-19T01:25:08Z",
        "updated_at": "2023-01-19T02:10:52Z",
        "last_entry_id": 27
    },
    "feeds": [
        {
            "created_at": "2023-01-19T02:08:43Z",
            "entry_id": 27,
            "field1": "51.90000",
            "field2": "40.00000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = data["feeds"][0]["field2"]
location = data["channel"]["latitude"] + "," + data["channel"]["longitude"]
output_data["location"] = location if location else None

# Write output JSON to file
with open("thingspeak/output_json/mistral/2010479.json", "w") as f:
    json.dump(output_data, f, indent=4)
