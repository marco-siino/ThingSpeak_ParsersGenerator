
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1243526,
        "name": "KS Hilden",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatur",
        "field2": "Luftfeuchtigkeit",
        "created_at": "2020-11-26T14:51:53Z",
        "updated_at": "2020-11-27T14:49:25Z",
        "last_entry_id": 1051201
    },
    "feeds": [
        {
            "created_at": "2023-05-03T06:05:04Z",
            "entry_id": 1051201,
            "field1": "16.2000007629",
            "field2": "50.7000007629"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant data from JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields as null if not present in the JSON text
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1243526.json", "w") as f:
    json.dump(output, f, indent=4)
