
import json
import os

# JSON text
json_text = """
{
    "channel": {
        "id": 2149687,
        "name": "MeteoMilano",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Umidit\u00e0",
        "created_at": "2023-05-16T13:11:23Z",
        "updated_at": "2023-05-18T13:23:13Z",
        "last_entry_id": 16
    },
    "feeds": [
        {
            "created_at": "2023-06-17T22:42:51Z",
            "entry_id": 16,
            "field1": "20.860000000000014",
            "field2": "67"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Create output JSON
output_json = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field1'],
    "humidity": data['feeds'][0]['field2'],
    "location": data['channel']['location'],
    # Add other fields as null if not present in the input JSON
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output JSON to file
output_path = "thingspeak/output_json/mistral/2149687.json"
with open(output_path, 'w') as f:
    json.dump(output_json, f, indent=4)
