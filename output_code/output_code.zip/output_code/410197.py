
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 410197,
        "name": "DHT22-working",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "field2": "Temperature",
        "created_at": "2018-01-24T09:49:43Z",
        "updated_at": "2019-02-22T15:07:09Z",
        "last_entry_id": 194124
    },
    "feeds": [
        {
            "created_at": "2019-04-15T05:03:43Z",
            "entry_id": 194124,
            "field1": "38.00000",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Initialize output data with schema properties
output_data = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0].get('field1', None),
    "humidity": None,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "location": data['channel']['location'],
    "soil_moisture": None,
    "hardware": data['channel']['name'],
    "distance": None,
    "ph": None
}

# Fill other fields if present in the JSON text
for key, value in data['channel'].items():
    if key not in output_data and key not in ['id', 'latitude', 'longitude', 'location']:
        output_data[key] = value

# Write output JSON to file
with open("thingspeak/output_json/mistral/410197.json", "w") as f:
    json.dump(output_data, f, indent=4)
