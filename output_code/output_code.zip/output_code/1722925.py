
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1722925,
        "name": "Estaci\u00f3n meteorol\u00f3gica",
        "description": "Tema 5 - Redes",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Humedad",
        "created_at": "2022-05-03T23:58:12Z",
        "updated_at": "2022-05-06T12:31:16Z",
        "last_entry_id": 311
    },
    "feeds": [
        {
            "created_at": "2022-05-17T13:02:10Z",
            "entry_id": 311,
            "field1": "29.40000",
            "field2": "20.00000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant fields from JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields as null if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output to file
with open("thingspeak/output_json/mistral/1722925.json", "w") as f:
    json.dump(output, f, indent=4)
