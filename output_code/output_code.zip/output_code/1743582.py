
import json

# JSON text
data = """
{
    "channel": {
        "id": 1743582,
        "name": "dht11",
        "latitude": "8.700941",
        "longitude": "77.44337",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2022-05-22T03:19:01Z",
        "updated_at": "2022-05-22T05:59:08Z",
        "last_entry_id": 7
    },
    "feeds": [
        {
            "created_at": "2022-05-22T10:21:12Z",
            "entry_id": 7,
            "field1": "27.10",
            "field2": "52.00    "
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
json_data = json.loads(data)
json_schema = json.loads(schema)

# Extract relevant data from JSON text
output_data = {
    "id": json_data["channel"]["id"],
    "temperature": json_data["feeds"][0]["field1"],
    "humidity": json_data["feeds"][0]["field2"],
    "location": f"{json_data['channel']['latitude']}, {json_data['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1743582.json", "w") as f:
    json.dump(output_data, f, indent=4)
