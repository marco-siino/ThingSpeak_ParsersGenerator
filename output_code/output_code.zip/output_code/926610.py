
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 926610,
        "name": "LED Control",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "led1",
        "field2": "led2",
        "field3": "led3",
        "created_at": "2019-12-02T00:54:19Z",
        "updated_at": "2019-12-02T00:59:01Z",
        "last_entry_id": 52
    },
    "feeds": [
        {
            "created_at": "2019-12-02T21:41:36Z",
            "entry_id": 52,
            "field1": "1",
            "field2": "1",
            "field3": "1"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields based on the semantic of the JSON text
output_data["temperature"] = None
output_data["humidity"] = None
output_data["pressure"] = None
output_data["light"] = ",".join(data["channel"][f"field{i}" for i in range(1, 4)])
output_data["air_quality"] = None
output_data["soil_moisture"] = None
output_data["hardware"] = None
output_data["distance"] = None
output_data["ph"] = None

# Create output file
import os
import time

output_file = "thingspeak/output_json/mistral/{}.json".format(data["channel"]["id"])
if not os.path.exists(os.path.dirname(output_file)):
    os.makedirs(os.path.dirname(output_file))

with open(output_file, "w") as f:
    json.dump(output_data, f, indent=4)

print(f"Output file saved at {output_file}")
