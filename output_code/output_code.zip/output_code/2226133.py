
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2226133,
        "name": "Laboratorio #2",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Humedad",
        "created_at": "2023-07-22T20:48:32Z",
        "updated_at": "2023-07-22T20:51:12Z",
        "last_entry_id": 107
    },
    "feeds": [
        {
            "created_at": "2023-07-24T05:09:30Z",
            "entry_id": 107,
            "field1": "24.10000",
            "field2": "75.80000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant fields from JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields if they are present in both JSON text and schema
    # ...
}

# Write output to a file
with open("thingspeak/output_json/mistral/2226133.json", "w") as f:
    json.dump(output, f, indent=4)
