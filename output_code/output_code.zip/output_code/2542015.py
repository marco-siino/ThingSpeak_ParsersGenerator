
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2542015,
        "name": "Capstone SACP School",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Soil Moisture",
        "field2": "Voltage",
        "created_at": "2024-05-09T07:06:42Z",
        "updated_at": "2024-05-15T02:20:02Z",
        "last_entry_id": 266837
    },
    "feeds": [
        {
            "created_at": "2024-07-18T09:11:42Z",
            "entry_id": 266837,
            "field1": null,
            "field2": "288.00000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["soil_moisture"] = data["channel"]["field1"]
output_data["hardware"] = "Capstone SACP School"
output_data["temperature"] = None
output_data["humidity"] = None
output_data["pressure"] = None
output_data["light"] = None
output_data["air_quality"] = None
output_data["distance"] = None
output_data["ph"] = None

# Add feed data if available
if len(data["feeds"]) > 0:
    feed = data["feeds"][0]
    output_data["temperature"] = feed.get("field2")

# Write output JSON to file
with open(r"thingspeak/output_json/mistral/2542015.json", "w") as f:
    json.dump(output_data, f, indent=4)
