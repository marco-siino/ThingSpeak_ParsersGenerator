
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1977955,
        "name": "Monitoring Humidity",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "created_at": "2022-12-12T04:25:31Z",
        "updated_at": "2022-12-12T05:18:36Z",
        "last_entry_id": 15
    },
    "feeds": [
        {
            "created_at": "2022-12-12T05:31:31Z",
            "entry_id": 15,
            "field1": "38.50000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["humidity"] = data["channel"]["field1"]

# Fill other fields with values from the feeds if available
for feed in data["feeds"]:
    if feed.get("field1"):
        if output_data.get("temperature") is None:
            output_data["temperature"] = feed["field1"]
        elif output_data.get("pressure") is None:
            output_data["pressure"] = feed["field1"]
        elif output_data.get("light") is None:
            output_data["light"] = feed["field1"]
        elif output_data.get("air_quality") is None:
            output_data["air_quality"] = feed["field1"]
        elif output_data.get("soil_moisture") is None:
            output_data["soil_moisture"] = feed["field1"]
        elif output_data.get("hardware") is None:
            output_data["hardware"] = feed["field1"]
        elif output_data.get("distance") is None:
            output_data["distance"] = feed["field1"]
        elif output_data.get("ph") is None:
            output_data["ph"] = feed["field1"]

# Write output JSON to file
with open("thingspeak/output_json/mistral/1977955.json", "w") as f:
    json.dump(output_data, f, indent=4)
