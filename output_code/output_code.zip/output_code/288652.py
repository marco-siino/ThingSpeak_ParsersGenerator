
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 288652,
        "name": "water quality and level  measurement",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Distance",
        "field4": "pH",
        "created_at": "2017-06-16T10:54:33Z",
        "updated_at": "2017-07-28T09:13:39Z",
        "last_entry_id": 100
    },
    "feeds": [
        {
            "created_at": "2017-07-28T09:13:39Z",
            "entry_id": 100,
            "field1": null,
            "field2": null,
            "field3": null,
            "field4": "2.62"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}" if data['channel']['latitude'] != "0.0" and data['channel']['longitude'] != "0.0" else None
output_data["temperature"] = data["channel"]["field1"] if data["channel"]["field1"] is not None else None
output_data["humidity"] = data["channel"]["field2"] if data["channel"]["field2"] is not None else None
output_data["pressure"] = None
output_data["light"] = None
output_data["air_quality"] = None
output_data["soil_moisture"] = None
output_data["hardware"] = None
output_data["distance"] = data["channel"]["field3"] if data["channel"]["field3"] is not None else None
output_data["ph"] = data["channel"]["field4"] if data["channel"]["field4"] is not None else None
output_data["feeds"] = []

# Add feeds to output data
for feed in data["feeds"]:
    feed_data = {}
    feed_data["created_at"] = feed["created_at"]
    feed_data["entry_id"] = feed["entry_id"]
    feed_data["temperature"] = feed["field1"] if feed["field1"] is not None else None
    feed_data["humidity"] = feed["field2"] if feed["field2"] is not None else None
    feed_data["pressure"] = None
    feed_data["light"] = None
    feed_data["air_quality"] = None
    feed_data["soil_moisture"] = None
    feed_data["hardware"] = None
    feed_data["distance"] = feed["field3"] if feed["field3"] is not None else None
    feed_data["ph"] = feed["field4"] if feed["field4"] is not None else None
    output_data["feeds"].append(feed_data)

# Write output data to file
with open("thingspeak/output_json/mistral/288652.json", "w") as f:
    json.dump(output_data, f, indent=4)
