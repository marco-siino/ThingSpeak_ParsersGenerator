
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 290080,
        "name": "Test_PEA",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temp",
        "field2": "Humidity",
        "created_at": "2017-06-20T06:28:07Z",
        "updated_at": "2017-06-20T12:56:39Z",
        "last_entry_id": 80
    },
    "feeds": [
        {
            "created_at": "2017-06-20T12:56:39Z",
            "entry_id": 80,
            "field1": "31.13007",
            "field2": "75.57373"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to a file
with open("thingspeak/output_json/mistral/290080.json", "w") as f:
    json.dump(output, f, indent=4)
