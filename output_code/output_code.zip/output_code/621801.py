
import json

def merge_coordinates(latitude, longitude):
    if latitude and longitude:
        return f"{latitude}, {longitude}"
    return None

def convert_json(json_text, schema):
    data = json.loads(json_text)
    output = {}

    for key, value in schema["properties"].items():
        if key in data:
            if key == "location":
                output[key] = merge_coordinates(data["channel"]["latitude"], data["channel"]["longitude"])
            else:
                output[key] = data[key]

    with open("thingspeak/output_json/mistral/621801.json", "w") as f:
        json.dump(output, f, indent=4)

json_text = """
{
    "channel": {
        "id": 621801,
        "name": "Dongshan",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "PM2.5",
        "created_at": "2018-11-08T06:53:15Z",
        "updated_at": "2018-11-08T06:53:15Z",
        "last_entry_id": 3
    },
    "feeds": [
        {
            "created_at": "2018-11-08T06:55:30Z",
            "entry_id": 3,
            "field1": "30"
        }
    ]
}
"""

schema = {
    "type": "object",
    "properties": {
        "id": {
            "type": "string"
        },
        "temperature": {
            "type": "string"
        },
        "humidity": {
            "type": "string"
        },
        "pressure": {
            "type": "string"
        },
        "light": {
            "type": "string"
        },
        "air_quality": {
            "type": "string"
        },
        "location": {
            "type": "string"
        },
        "soil_moisture": {
            "type": "string"
        },
        "hardware": {
            "type": "string"
        },
        "distance": {
            "type": "string"
        },
        "ph": {
            "type": "string"
        }
    }
}

convert_json(json_text, schema)
