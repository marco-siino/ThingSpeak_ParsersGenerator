
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 226232,
        "name": "ARDUINO+ESP8266_01+TEMPERATURE",
        "description": "Invio dati temperatura con Arduino + ESP8266 + Sensore Temperatura",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "created_at": "2017-02-11T15:29:11Z",
        "updated_at": "2017-02-11T17:47:22Z",
        "last_entry_id": 352
    },
    "feeds": [
        {
            "created_at": "2017-02-11T17:47:22Z",
            "entry_id": 352,
            "field1": "1.47"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["channel"]["field1"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Write output JSON to file
with open("thingspeak/output_json/mistral/226232.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
