
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1621067,
        "name": "Artjom's Home",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2021-12-29T19:24:06Z",
        "updated_at": "2021-12-29T22:41:15Z",
        "last_entry_id": 2540602
    },
    "feeds": [
        {
            "created_at": "2024-05-28T06:09:10Z",
            "entry_id": 2540602,
            "field1": "18",
            "field2": "54"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Initialize output JSON
output = {}
output['id'] = data['channel']['id']
output['temperature'] = data['feeds'][0]['field1']
output['humidity'] = data['feeds'][0]['field2']
output['location'] = data['channel']['location']

# Fill other fields with null values
output['pressure'] = None
output['light'] = None
output['air_quality'] = None
output['soil_moisture'] = None
output['hardware'] = None
output['distance'] = None
output['ph'] = None

# Write output JSON to file
with open('thingspeak/output_json/mistral/1621067.json', 'w') as f:
    json.dump(output, f, indent=4)
