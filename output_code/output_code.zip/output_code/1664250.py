
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1664250,
        "name": "Air sensor",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Pressure",
        "field3": "Humidity",
        "created_at": "2022-02-28T08:34:32Z",
        "updated_at": "2022-03-28T08:07:25Z",
        "last_entry_id": 621
    },
    "feeds": [
        {
            "created_at": "2022-03-28T08:36:56Z",
            "entry_id": 621,
            "field1": "24.32",
            "field2": "996.52",
            "field3": "19.34"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output JSON
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field3"],
    "pressure": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the input JSON
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1664250.json", "w") as f:
    json.dump(output, f, indent=4)
