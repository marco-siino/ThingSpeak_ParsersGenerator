
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 659830,
        "name": "Smart Agriculture System",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Soil Moisture",
        "field2": null,
        "field3": null,
        "created_at": "2018-12-21T06:40:43Z",
        "updated_at": "2019-07-05T07:19:09Z",
        "last_entry_id": 51
    },
    "feeds": [
        {
            "created_at": "2019-07-27T17:07:10Z",
            "entry_id": 51,
            "field1": "300",
            "field2": null,
            "field3": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output_json = {}
output_json['id'] = data['channel']['id']
output_json['location'] = data['channel']['location']
output_json['soil_moisture'] = data['channel']['field1']

# Iterate through feeds and populate output JSON
for feed in data['feeds']:
    for key, value in feed.items():
        if value is not None:
            if key in json.loads(json_schema)['properties']:
                output_json[key] = value

# Write output JSON to file
with open('thingspeak/output_json/mistral/659830.json', 'w') as f:
    json.dump(output_json, f, indent=4)
