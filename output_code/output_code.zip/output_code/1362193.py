
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1362193,
        "name": "Wetterstation ESP8266-DHT11",
        "description": "Wetterstation + DHT11",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Light",
        "field4": "Atmosphere",
        "created_at": "2021-04-18T14:40:47Z",
        "updated_at": "2021-04-18T15:57:41Z",
        "last_entry_id": 2543
    },
    "feeds": [
        {
            "created_at": "2021-04-25T13:57:18Z",
            "entry_id": 2543,
            "field1": "22",
            "field2": "50",
            "field3": "221",
            "field4": "101194"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the "channel" object
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["feeds"][0]["field1"],
    "humidity": data["channel"]["feeds"][0]["field2"],
    "light": data["channel"]["feeds"][0]["field3"],
    "air_quality": data["channel"]["field4"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}" if data['channel']['latitude'] != "0.0" and data['channel']['longitude'] != "0.0" else None,
    # Add other fields as null if not present in the JSON text
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output to a file
with open("thingspeak/output_json/mistral/1362193.json", "w") as f:
    json.dump(output, f, indent=4)
