
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2479303,
        "name": "DSB WIFI CLOUD 140/2479303",
        "description": "Nextcon LTDA",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2024-03-20T18:20:00Z",
        "updated_at": "2024-03-20T18:20:06Z",
        "last_entry_id": 2106
    },
    "feeds": [
        {
            "created_at": "2024-05-16T14:30:39Z",
            "entry_id": 2106,
            "field1": "23.1",
            "field2": "22.9",
            "field3": "26.5"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": None,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to a file
with open("thingspeak/output_json/mistral/2479303.json", "w") as f:
    json.dump(output, f, indent=4)
