
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 469847,
        "name": "sensor",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2018-04-08T17:16:10Z",
        "updated_at": "2018-04-08T21:05:10Z",
        "last_entry_id": 83
    },
    "feeds": [
        {
            "created_at": "2018-04-08T21:05:11Z",
            "entry_id": 83,
            "field1": "26.00",
            "field2": "46.00"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant fields from JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["field1"],
    "humidity": data["channel"]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields as null if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Process feeds and add relevant fields to output
for feed in data["feeds"]:
    output["temperature"] = feed["field1"]
    output["humidity"] = feed["field2"]

# Write output to file
with open("thingspeak/output_json/mistral/469847.json", "w") as f:
    json.dump(output, f, indent=4)
