
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1384438,
        "name": "average humidity",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "created_at": "2021-05-08T14:42:01Z",
        "updated_at": "2021-05-08T18:29:39Z",
        "last_entry_id": 2
    },
    "feeds": [
        {
            "created_at": "2021-05-08T15:23:04Z",
            "entry_id": 2,
            "field1": "54.44776119402985"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["humidity"] = data["channel"]["field1"]
output_data["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Fill other fields with values from the feeds if available
for feed in data["feeds"]:
    if feed.get("field1"):
        output_data.setdefault("temperature", None)
        output_data.setdefault("pressure", None)
        output_data.setdefault("light", None)
        output_data.setdefault("air_quality", None)
        output_data.setdefault("soil_moisture", None)
        output_data.setdefault("hardware", None)
        output_data.setdefault("distance", None)
        output_data.setdefault("ph", None)

        # Assign values from the feed if not already set
        if output_data["temperature"] is None:
            output_data["temperature"] = feed.get("field1")
        if output_data["pressure"] is None:
            output_data["pressure"] = feed.get("field1")
        if output_data["light"] is None:
            output_data["light"] = feed.get("field1")
        if output_data["air_quality"] is None:
            output_data["air_quality"] = feed.get("field1")
        if output_data["soil_moisture"] is None:
            output_data["soil_moisture"] = feed.get("field1")
        if output_data["hardware"] is None:
            output_data["hardware"] = feed.get("field1")
        if output_data["distance"] is None:
            output_data["distance"] = feed.get("field1")
        if output_data["ph"] is None:
            output_data["ph"] = feed.get("field1")

# Write output JSON to file
with open("thingspeak/output_json/mistral/1384438.json", "w") as f:
    json.dump(output_data, f, indent=4)
