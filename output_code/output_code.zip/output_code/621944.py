
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 621944,
        "name": "Humidity , Temperature, And Gas Sensor",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Gas",
        "created_at": "2018-11-08T10:52:37Z",
        "updated_at": "2018-11-26T11:30:25Z",
        "last_entry_id": 35
    },
    "feeds": [
        {
            "created_at": "2019-01-26T10:25:56Z",
            "entry_id": 35,
            "field1": "33.4000020000",
            "field2": "82.9000020000",
            "field3": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the channel object
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["field1"],
    "humidity": data["channel"]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields as empty strings or null values if not present in the JSON text
    "pressure": "",
    "light": "",
    "air_quality": "",
    "soil_moisture": "",
    "hardware": "",
    "distance": "",
    "ph": ""
}

# Parse the feeds list and add feed data to the output
for feed in data["feeds"]:
    feed_data = {
        "created_at": feed["created_at"],
        "entry_id": feed["entry_id"]
    }
    feed_data.update({f"{key}": feed[key] for key in ["temperature", "humidity"] if feed[key] is not None})
    output["feeds"] = [feed_data] if not output["feeds"] else output["feeds"] + [feed_data]

# Write the output JSON to a file
with open("thingspeak/output_json/mistral/621944.json", "w") as f:
    json.dump(output, f, indent=4)
