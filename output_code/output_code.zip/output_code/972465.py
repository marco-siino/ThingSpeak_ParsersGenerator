
import json

def merge_location(latitude, longitude):
    if latitude and longitude:
        return f"{latitude}, {longitude}"
    return None

def convert_json(json_text, schema):
    json_data = json.loads(json_text)

    output_data = {
        "id": json_data["channel"]["id"],
        "location": merge_location(json_data["channel"]["latitude"], json_data["channel"]["longitude"]),
        "temperature": json_data["feeds"][0].get("field2", None),
        "humidity": json_data["feeds"][0].get("field1", None),
        "pressure": json_data["feeds"][0].get("field3", None),
        "light": None,
        "air_quality": None,
        "soil_moisture": None,
        "hardware": None,
        "distance": json_data["feeds"][0].get("field4", None),
        "ph": None
    }

    with open("thingspeak/output_json/mistral/{}.json".format(json_data["channel"]["id"]), "w") as outfile:
        json.dump(output_data, outfile, indent=4)

json_text = """
{
    "channel": {
        "id": 972465,
        "name": "Patient_1",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "field2": null,
        "field3": null,
        "field4": "111",
        "created_at": "2020-01-27T04:48:31Z",
        "updated_at": "2020-04-08T09:11:35Z",
        "last_entry_id": 1135
    },
    "feeds": [
        {
            "created_at": "2020-03-16T05:04:55Z",
            "entry_id": 1135,
            "field1": null,
            "field2": null,
            "field3": null,
            "field4": "111"
        }
    ]
}
"""

schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

convert_json(json_text, schema)
