
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 990801,
        "name": "DHT22  Temperature and humidity",
        "description": "  Temperature and humidity",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "humidity",
        "created_at": "2020-02-14T05:27:46Z",
        "updated_at": "2020-02-19T08:21:12Z",
        "last_entry_id": 30647
    },
    "feeds": [
        {
            "created_at": "2022-11-11T01:14:36Z",
            "entry_id": 30647,
            "field1": "24.40",
            "field2": "75.10    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = data["feeds"][0]["field2"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Write output JSON to file
with open("thingspeak/output_json/mistral/990801.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
