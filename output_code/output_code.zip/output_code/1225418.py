
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1225418,
        "name": "BME280 Weather",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "field3": "pressure",
        "created_at": "2020-11-10T16:34:20Z",
        "updated_at": "2020-11-16T04:13:32Z",
        "last_entry_id": 23573
    },
    "feeds": [
        {
            "created_at": "2021-06-16T18:44:07Z",
            "entry_id": 23573,
            "field1": "36.819609878",
            "field2": "43.2515914033",
            "field3": "1009.45338796"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "pressure": data["feeds"][0]["field3"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1225418.json", "w") as f:
    json.dump(output_data, f, indent=4)
