
import json

# JSON text
data = """
{
    "channel": {
        "id": 503350,
        "name": "Temperatura-Lm35",
        "description": "registro de temperatura no tempo atrav\u00e9s de um sensor lm35 e a placa NodeMcu",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "created_at": "2018-05-24T03:30:55Z",
        "updated_at": "2018-07-27T13:18:27Z",
        "last_entry_id": 1876
    },
    "feeds": [
        {
            "created_at": "2018-08-11T13:28:46Z",
            "entry_id": 1876,
            "field1": "25.16    "
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
json_data = json.loads(data)
json_schema = json.loads(schema)

# Extract required fields from JSON data
output = {
    "id": json_data["channel"]["id"],
    "temperature": json_data["channel"]["feeds"][0]["field1"],
    "location": json_data["channel"]["latitude"] + "," + json_data["channel"]["longitude"],
    # Add other fields as null if not present in the JSON data
    "humidity": "null",
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/503350.json", "w") as f:
    json.dump(output, f, indent=4)
