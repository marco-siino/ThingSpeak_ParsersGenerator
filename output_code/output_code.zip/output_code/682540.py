
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 682540,
        "name": "R+H  LCD + nodemcu",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "HUMIDITY",
        "field2": "TEMPERATURE",
        "created_at": "2019-01-19T18:56:28Z",
        "updated_at": "2019-11-03T02:50:10Z",
        "last_entry_id": 160138
    },
    "feeds": [
        {
            "created_at": "2024-07-21T00:19:43Z",
            "entry_id": 160138,
            "field1": "84.70",
            "field2": "29.20"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field2'],
    "humidity": data['feeds'][0]['field1'],
    "location": data['channel']['location'],
    # Add other fields with null values
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/682540.json", "w") as f:
    json.dump(output, f, indent=4)
