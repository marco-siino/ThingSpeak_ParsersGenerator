
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1365436,
        "name": "Wifi Data Logger Test",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Light",
        "created_at": "2021-04-20T22:45:20Z",
        "updated_at": "2021-04-21T18:10:26Z",
        "last_entry_id": 124
    },
    "feeds": [
        {
            "created_at": "2021-04-21T21:43:04Z",
            "entry_id": 124,
            "field1": "52.0",
            "field2": "756"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output JSON
output = {}
output["id"] = data["channel"]["id"]
output["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output["temperature"] = data["channel"]["field1"] if data["channel"]["field1"] else None
output["humidity"] = None
output["pressure"] = None
output["light"] = data["channel"]["field2"] if data["channel"]["field2"] else None
output["air_quality"] = None
output["soil_moisture"] = None
output["hardware"] = None
output["distance"] = None
output["ph"] = None

# Process feeds
for feed in data["feeds"]:
    entry = {}
    entry["temperature"] = feed["field1"] if feed["field1"] else None
    entry["light"] = feed["field2"] if feed["field2"] else None
    output[f"feed_{feed['entry_id']}"] = entry

# Write output JSON to file
with open("thingspeak/output_json/mistral/1365436.json", "w") as f:
    json.dump(output, f, indent=4)
