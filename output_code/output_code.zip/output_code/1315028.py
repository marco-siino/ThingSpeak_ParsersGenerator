
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1315028,
        "name": "Act3.2 for IoT",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Pressure",
        "created_at": "2021-03-01T08:48:14Z",
        "updated_at": "2021-03-01T09:47:18Z",
        "last_entry_id": 232
    },
    "feeds": [
        {
            "created_at": "2022-03-23T15:51:33Z",
            "entry_id": 232,
            "field1": "19.71",
            "field2": null,
            "field3": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Create output JSON with schema structure
output_data = {
    "id": data['channel']['id'],
    "temperature": data['channel']['field1'],
    "humidity": data['channel']['field2'],
    "pressure": data['channel']['field3'],
    "location": data['channel']['location'],
    # Add other fields from the schema if they exist in the JSON text
    "light": data.get('channel', {}).get('field4', None),
    "air_quality": data.get('channel', {}).get('field5', None),
    "soil_moisture": data.get('channel', {}).get('field6', None),
    "hardware": data.get('channel', {}).get('field7', None),
    "distance": data.get('channel', {}).get('field8', None),
    "ph": data.get('channel', {}).get('field9', None)
}

# Add feeds data if it exists
if 'feeds' in data:
    feed = data['feeds'][0]
    output_data['created_at'] = feed['created_at']
    output_data['entry_id'] = feed['entry_id']
    output_data['temperature'] = feed['field1']
    output_data['humidity'] = feed['field2']
    output_data['pressure'] = feed['field3']

# Write output JSON to file
with open("thingspeak/output_json/mistral/1315028.json", "w") as f:
    json.dump(output_data, f, indent=4)
