
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 216780,
        "name": "dario test ",
        "description": "temperature of home",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2017-01-20T08:38:40Z",
        "updated_at": "2017-02-22T07:50:04Z",
        "last_entry_id": 6
    },
    "feeds": [
        {
            "created_at": "2017-02-22T07:50:04Z",
            "entry_id": 6,
            "field1": "21.00",
            "field2": "67.00"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Initialize output data with schema properties
output_data = {
    "id": data['channel']['id'],
    "temperature": data['channel']['feeds'][0]['field1'],
    "humidity": data['channel']['feeds'][0]['field2'],
    "location": data['channel']['location'],
    # Add other fields with null values if not present in the input data
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/216780.json", "w") as f:
    json.dump(output_data, f, indent=4)
