
import json

# JSON text
data = """
{
    "channel": {
        "id": 779941,
        "name": "Mesurements",
        "description": "Measurement of temperature e Humidity",
        "latitude": "-23.64",
        "longitude": "-46.58",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2019-05-13T16:42:38Z",
        "updated_at": "2019-05-14T18:26:02Z",
        "elevation": "796",
        "last_entry_id": 10432
    },
    "feeds": [
        {
            "created_at": "2019-06-05T15:57:17Z",
            "entry_id": 10432,
            "field1": "22",
            "field2": null
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
json_data = json.loads(data)
json_schema = json.loads(schema)

# Extract data from JSON text
output_data = {
    "id": json_data["channel"]["id"],
    "temperature": json_data["channel"]["field1"],
    "humidity": json_data["channel"]["field2"] if json_data["channel"]["field2"] else None,
    "location": f"{json_data['channel']['latitude']}, {json_data['channel']['longitude']}",
    # Add other fields as empty if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/779941.json", "w") as f:
    json.dump(output_data, f, indent=4)
