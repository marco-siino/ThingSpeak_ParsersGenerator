
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2552038,
        "name": "ch1_temperature/humidity",
        "description": "temperature & humidity sensor(dht11)",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": null,
        "created_at": "2024-05-17T06:39:09Z",
        "updated_at": "2024-05-17T06:40:20Z",
        "last_entry_id": 21
    },
    "feeds": [
        {
            "created_at": "2024-05-17T08:24:01Z",
            "entry_id": 21,
            "field1": "27.60000",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Extract relevant fields from data
output = {
    "id": data['channel']['id'],
    "temperature": data['channel']['field1'],
    "humidity": None if data['channel']['field2'] is None else data['channel']['field2'],
    "location": data['channel']['location'],
    # Add other fields from schema if they exist in the data
    # ...
}

# Add feeds to output
output['feeds'] = [feed for feed in data['feeds'] if feed['field1'] is not None]

# Write output to file
with open('thingspeak/output_json/mistral/2552038.json', 'w') as f:
    json.dump(output, f, indent=4)
