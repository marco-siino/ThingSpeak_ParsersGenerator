
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1182937,
        "name": "iot",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temp",
        "field2": "humidity",
        "created_at": "2020-10-11T08:01:27Z",
        "updated_at": "2020-10-11T08:01:50Z",
        "last_entry_id": 225
    },
    "feeds": [
        {
            "created_at": "2020-10-18T19:03:13Z",
            "entry_id": 225,
            "field1": "700",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Extract relevant fields from the JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["field1"],
    "humidity": data["channel"]["field2"]
}

# If a field has a value other than null, include it in the output
for field in ["pressure", "light", "air_quality", "soil_moisture", "hardware", "distance", "ph"]:
    if field in data and data[field] is not None:
        output[field] = data[field]

# Write output to a file
with open("thingspeak/output_json/mistral/1182937.json", "w") as f:
    json.dump(output, f, indent=4)
