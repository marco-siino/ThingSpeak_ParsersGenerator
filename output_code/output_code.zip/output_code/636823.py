
import json

def merge_location(data):
    if data["channel"]["latitude"] and data["channel"]["longitude"]:
        data["channel"]["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"
        del data['channel']['latitude']
        del data['channel']['longitude']
    return data

def write_to_file(data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 636823,
        "name": "ESP8266 Signal Strength",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "RSSI",
        "created_at": "2018-11-26T13:34:17Z",
        "updated_at": "2018-11-29T11:46:49Z",
        "last_entry_id": 57
    },
    "feeds": [
        {
            "created_at": "2018-11-30T11:46:14Z",
            "entry_id": 57,
            "field1": "60"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge location field
data = merge_location(data)

# Create output JSON based on schema
output_data = {}
for key, value in json.loads(schema)["properties"].items():
    output_data[key] = data.get(key, None) if key in data else None

# Write output JSON to file
write_to_file(output_data, "thingspeak/output_json/mistral/636823.json")
