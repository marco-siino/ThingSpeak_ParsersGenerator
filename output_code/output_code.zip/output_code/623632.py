
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 623632,
        "name": "MSWeather",
        "description": "MyStation",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Light",
        "field4": "Atmosphere",
        "created_at": "2018-11-10T20:30:07Z",
        "updated_at": "2018-11-10T20:30:07Z",
        "last_entry_id": 17271
    },
    "feeds": [
        {
            "created_at": "2024-07-14T21:09:25Z",
            "entry_id": 17271,
            "field1": "23",
            "field2": "61",
            "field3": "10",
            "field4": "96682"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema_data = json.loads(schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = data["feeds"][0]["field2"]
output_data["light"] = data["feeds"][0]["field3"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["air_quality"] = None
output_data["soil_moisture"] = None
output_data["hardware"] = None
output_data["distance"] = None
output_data["ph"] = None

# Write output JSON to file
with open("thingspeak/output_json/mistral/623632.json", "w") as f:
    json.dump(output_data, f, indent=4)
