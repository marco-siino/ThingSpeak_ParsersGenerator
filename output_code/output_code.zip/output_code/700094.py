
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 700094,
        "name": "PI Sensors",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2019-02-10T20:08:25Z",
        "updated_at": "2019-02-11T17:38:26Z",
        "last_entry_id": 36362
    },
    "feeds": [
        {
            "created_at": "2019-02-20T20:01:45Z",
            "entry_id": 36362,
            "field1": "27.299999237060547",
            "field2": "28.899999618530273"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant data from JSON text
channel = data['channel']
feed = data['feeds'][0]

# Merge latitude and longitude into location
location = f"{channel['latitude']}, {channel['longitude']}"

# Create output JSON
output = {
    "id": channel['id'],
    "temperature": channel['field1'],
    "humidity": channel['field2'],
    "location": location,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

output['pressure'] = feed['created_at']  # Use created_at for pressure (assuming it represents a timestamp)

# Write output JSON to file
with open('thingspeak/output_json/mistral/700094.json', 'w') as f:
    json.dump(output, f, indent=4)
