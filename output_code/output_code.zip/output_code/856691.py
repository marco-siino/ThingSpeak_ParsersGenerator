
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 856691,
        "name": "Humidity and Temperature Analysis",
        "description": "For analysis of temperature and humidity measured witha DHT11 Sensor",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "field2": "Temperature",
        "created_at": "2019-09-01T06:28:06Z",
        "updated_at": "2022-10-17T06:40:50Z",
        "last_entry_id": 69
    },
    "feeds": [
        {
            "created_at": "2019-09-01T06:56:44Z",
            "entry_id": 69,
            "field1": "28.0",
            "field2": "51.0"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output_json = {}
output_json['id'] = data['channel']['id']
output_json['temperature'] = data['feeds'][0]['field2']
output_json['humidity'] = data['feeds'][0]['field1']

# Fill other fields with null values
output_json['pressure'] = None
output_json['light'] = None
output_json['air_quality'] = None
output_json['soil_moisture'] = None
output_json['hardware'] = None
output_json['distance'] = None
output_json['ph'] = None

# Write output JSON to file
with open('thingspeak/output_json/mistral/856691.json', 'w') as f:
    json.dump(output_json, f, indent=4)
