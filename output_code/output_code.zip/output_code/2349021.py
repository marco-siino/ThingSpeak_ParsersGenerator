
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2349021,
        "name": "Second Station",
        "description": "Weather Station 2",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Light",
        "field4": "Atmosphere",
        "created_at": "2023-11-17T16:58:16Z",
        "updated_at": "2023-11-17T16:58:33Z",
        "last_entry_id": 26
    },
    "feeds": [
        {
            "created_at": "2023-11-17T20:56:21Z",
            "entry_id": 26,
            "field1": "22",
            "field2": "48",
            "field3": "0",
            "field4": "98722"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output JSON
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the input JSON
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/2349021.json", "w") as f:
    json.dump(output, f, indent=4)
