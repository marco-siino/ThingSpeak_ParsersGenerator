
import json

data = {
    "channel": {
        "id": 592833,
        "name": "weather",
        "description": "weather of NITRKL",
        "latitude": "22.252192",
        "longitude": "84.910853",
        "field1": "temp",
        "created_at": "2018-10-02T14:59:56Z",
        "updated_at": "2018-10-05T19:47:09Z",
        "last_entry_id": 1620
    },
    "feeds": [
        {
            "created_at": "2018-10-06T20:17:53Z",
            "entry_id": 1620,
            "field1": "23.00"
        }
    ]
}

schema = {
    "type": "object",
    "properties": {
        "id": {
            "type": "string"
        },
        "temperature": {
            "type": "string"
        },
        "humidity": {
            "type": "string"
        },
        "pressure": {
            "type": "string"
        },
        "light": {
            "type": "string"
        },
        "air_quality": {
            "type": "string"
        },
        "location": {
            "type": "string"
        },
        "soil_moisture": {
            "type": "string"
        },
        "hardware": {
            "type": "string"
        },
        "distance": {
            "type": "string"
        },
        "ph": {
            "type": "string"
        }
    }
}

output_data = {
    "id": data["channel"]["id"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    "temperature": data["feeds"][0]["field1"] if data["feeds"] else None,
    # Add other fields as needed
}

with open("thingspeak/output_json/mistral/592833.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
