
import json

# JSON text
data = """
{
    "channel": {
        "id": 1741592,
        "name": "Sensor data from AM2302",
        "description": "Temperature & Humidity data at 15 second intervals",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2022-05-20T01:45:06Z",
        "updated_at": "2022-05-20T01:45:29Z",
        "last_entry_id": 10
    },
    "feeds": [
        {
            "created_at": "2022-05-20T01:54:19Z",
            "entry_id": 10,
            "field1": "26",
            "field2": "65"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
json_data = json.loads(data)
json_schema = json.loads(schema)

# Extract relevant fields from JSON data
output = {
    "id": json_data["channel"]["id"],
    "temperature": json_data["feeds"][0]["field1"],
    "humidity": json_data["feeds"][0]["field2"],
    "location": f"{json_data['channel']['latitude']}, {json_data['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1741592.json", "w") as f:
    json.dump(output, f, indent=4)
