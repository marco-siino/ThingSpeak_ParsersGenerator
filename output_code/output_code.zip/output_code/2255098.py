
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2255098,
        "name": "dht1 1 sensor based reading",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temp",
        "field2": "humidity",
        "created_at": "2023-08-30T04:17:14Z",
        "updated_at": "2023-09-14T02:47:10Z",
        "last_entry_id": 166
    },
    "feeds": [
        {
            "created_at": "2023-09-14T02:51:41Z",
            "entry_id": 166,
            "field1": "28.0",
            "field2": "66.0"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Extract relevant data from the JSON text
output_data = {
    "id": data['channel']['id'],
    "temperature": data['feeds'][0]['field1'],
    "humidity": data['feeds'][0]['field2'],
    "location": data['location']
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/2255098.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
