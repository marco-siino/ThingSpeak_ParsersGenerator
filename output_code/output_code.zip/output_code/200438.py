
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 200438,
        "name": "smartchair 1.0",
        "description": "python program chair",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "pressure",
        "field2": "temp",
        "created_at": "2016-12-07T10:50:21Z",
        "updated_at": "2016-12-07T11:03:37Z",
        "last_entry_id": 3
    },
    "feeds": [
        {
            "created_at": "2016-12-07T11:03:37Z",
            "entry_id": 3,
            "field1": "50",
            "field2": "70"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields based on the semantic of the JSON text
if "feeds" in data and len(data["feeds"]) > 0:
    feed = data["feeds"][0]
    output_data["temperature"] = feed["field2"]
    output_data["pressure"] = feed["field1"]

# Write output JSON to a file
with open("thingspeak/output_json/mistral/200438.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
