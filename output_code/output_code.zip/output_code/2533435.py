
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2533435,
        "name": "Lab 7",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": null,
        "created_at": "2024-05-02T22:49:04Z",
        "updated_at": "2024-05-02T22:56:55Z",
        "last_entry_id": 18
    },
    "feeds": [
        {
            "created_at": "2024-05-02T23:02:54Z",
            "entry_id": 18,
            "field1": "67.20000",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = None  # replace with appropriate value if available
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["pressure"] = None  # replace with appropriate value if available
output_data["light"] = None  # replace with appropriate value if available
output_data["air_quality"] = None  # replace with appropriate value if available
output_data["soil_moisture"] = None  # replace with appropriate value if available
output_data["hardware"] = None  # replace with appropriate value if available
output_data["distance"] = None  # replace with appropriate value if available
output_data["ph"] = None  # replace with appropriate value if available

# Write output JSON to file
with open("thingspeak/output_json/mistral/2533435.json", "w") as f:
    json.dump(output_data, f, indent=4)
