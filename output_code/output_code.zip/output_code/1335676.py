
import json

# JSON text
input_json = """
{
    "channel": {
        "id": 1335676,
        "name": "HIGROMETRO GSM-5",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Humedad",
        "created_at": "2021-03-22T23:35:29Z",
        "updated_at": "2021-03-22T23:35:43Z",
        "last_entry_id": 11
    },
    "feeds": [
        {
            "created_at": "2021-04-30T17:18:04Z",
            "entry_id": 11,
            "field1": "020.5",
            "field2": "28"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse the input JSON
data = json.loads(input_json)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize the output JSON
output = {
    "id": data['channel']['id'],
    "temperature": data['channel']['feeds'][0]['field1'],
    "humidity": data['channel']['feeds'][0]['field2'],
    "location": data['channel']['location'],
    # Add other fields with null values if not present in the input JSON
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write the output JSON to a file
with open("thingspeak/output_json/mistral/1335676.json", "w") as f:
    json.dump(output, f, indent=4)
