
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2017557,
        "name": "Mini.Weather.Station",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Pressure",
        "field3": "Humidity",
        "created_at": "2023-01-26T15:31:13Z",
        "updated_at": "2023-01-26T15:31:28Z",
        "last_entry_id": 12
    },
    "feeds": [
        {
            "created_at": "2023-02-01T11:21:36Z",
            "entry_id": 12,
            "field1": "23.77",
            "field2": "1004.80",
            "field3": "43.2"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = data["feeds"][0]["field3"]
output_data["pressure"] = data["feeds"][0]["field2"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Write output JSON to file
with open("thingspeak/output_json/mistral/2017557.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
