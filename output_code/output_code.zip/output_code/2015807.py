
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2015807,
        "name": "Dew Point Measurement",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Distance",
        "field2": "humidity",
        "field3": "temperature",
        "created_at": "2023-01-24T17:12:58Z",
        "updated_at": "2023-12-29T17:19:46Z",
        "last_entry_id": 2901
    },
    "feeds": [
        {
            "created_at": "2023-12-30T21:20:11Z",
            "entry_id": 2901,
            "field1": "52.4104",
            "field2": "56",
            "field3": "21"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field3"]
output_data["humidity"] = data["feeds"][0]["field2"]
location = data["channel"]["latitude"] + "," + data["channel"]["longitude"]
output_data["location"] = location if location else None

# Write output JSON to file
with open("thingspeak/output_json/mistral/2015807.json", "w") as f:
    json.dump(output_data, f, indent=4)
