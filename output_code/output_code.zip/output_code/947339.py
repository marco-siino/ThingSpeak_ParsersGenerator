
import json

def merge_coordinates(data):
    if 'latitude' in data and 'longitude' in data:
        data['location'] = f"{data['latitude']}, {data['longitude']}"
        del data['latitude']
        del data['longitude']
    return data

def write_to_file(output_file, data):
    with open(output_file, 'w') as f:
        json.dump(data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 947339,
        "name": "led",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "led1",
        "field2": "led2",
        "field3": "led3",
        "created_at": "2019-12-28T05:53:44Z",
        "updated_at": "2019-12-28T07:05:17Z",
        "last_entry_id": 18
    },
    "feeds": [
        {
            "created_at": "2019-12-28T07:07:09Z",
            "entry_id": 18,
            "field1": null,
            "field2": null,
            "field3": "1"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data = merge_coordinates(data['channel'])

# Create output JSON based on schema
output_data = {
    "id": data['channel']['id'],
    "temperature": data['channel'].get('field1', 'null'),
    "humidity": data['channel'].get('field2', 'null'),
    "pressure": data['channel'].get('field3', 'null'),
    "light": data['channel'].get('field1', data['channel'].get('field2', data['channel'].get('field3', 'null'))),
    "air_quality": 'null',
    "location": data['channel']['location'],
    "soil_moisture": 'null',
    "hardware": 'null',
    "distance": 'null',
    "ph": 'null'
}

# Add feeds to output JSON
output_data['feeds'] = [feed for feed in data['feeds'] if feed.get('field3') is not None]

# Write output JSON to file
write_to_file("thingspeak/output_json/mistral/947339.json", output_data)
