
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 868244,
        "name": "Temperatue and humidity monitor",
        "description": "ESP32 + DHT22;   For monitoring temperature and humidity inside a summer house",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2019-09-21T04:03:54Z",
        "updated_at": "2019-09-29T08:24:04Z",
        "last_entry_id": 87353
    },
    "feeds": [
        {
            "created_at": "2020-12-10T18:22:57Z",
            "entry_id": 87353,
            "field1": "2.00000",
            "field2": "56.50000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "pressure": "null",
    "light": "null",
    "air_quality": "null",
    "soil_moisture": "null",
    "hardware": "null",
    "distance": "null",
    "ph": "null"
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/868244.json", "w") as f:
    json.dump(output, f, indent=4)
