
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 562126,
        "name": "Swallow's Weather Station",
        "description": "Graphs of data collected from Sense HAT",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "pressure",
        "field3": "humidity",
        "created_at": "2018-08-21T15:41:52Z",
        "updated_at": "2018-08-24T11:09:34Z",
        "last_entry_id": 25
    },
    "feeds": [
        {
            "created_at": "2018-08-24T14:49:21Z",
            "entry_id": 25,
            "field1": "34.3",
            "field2": "1013.3",
            "field3": "34.4"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output = {
    "id": data['channel']['id'],
    "temperature": data['channel']['feeds'][0]['field1'],
    "humidity": data['channel']['feeds'][0]['field3'],
    "pressure": data['channel']['feeds'][0]['field2'],
    "location": data['channel']['location']
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/562126.json", "w") as f:
    json.dump(output, f, indent=4)
