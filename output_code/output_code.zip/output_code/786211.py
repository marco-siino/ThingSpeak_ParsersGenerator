
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 786211,
        "name": "Monitoring  Soil Moisture of TOMATO Plants with Internet_Of_Things",
        "description": "Soilmoisture",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Humidity",
        "created_at": "2019-05-22T13:53:18Z",
        "updated_at": "2019-05-22T14:58:42Z",
        "last_entry_id": 1495
    },
    "feeds": [
        {
            "created_at": "2019-07-16T04:51:40Z",
            "entry_id": 1495,
            "field1": "1024    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"
output_data["humidity"] = data["channel"]["field1"]

# Fill other fields with null values if not present in the input data
for field in schema["properties"]:
    if field not in output_data:
        output_data[field] = None

# Write output JSON to file
with open("thingspeak/output_json/mistral/786211.json", "w") as f:
    json.dump(output_data, f, indent=4)
