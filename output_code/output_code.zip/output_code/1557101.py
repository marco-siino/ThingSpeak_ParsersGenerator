
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1557101,
        "name": "scr rasp pi",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temp",
        "field2": "pressure",
        "field3": "humidity",
        "created_at": "2021-11-02T14:56:06Z",
        "updated_at": "2021-11-02T15:15:24Z",
        "last_entry_id": 21
    },
    "feeds": [
        {
            "created_at": "2021-11-02T15:18:12Z",
            "entry_id": 21,
            "field1": "33.03038787841797",
            "field2": "27.0972843170166",
            "field3": "993.521484375"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant fields from the JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field3"],
    "pressure": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if needed
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/1557101.json", "w") as f:
    json.dump(output, f, indent=4)
