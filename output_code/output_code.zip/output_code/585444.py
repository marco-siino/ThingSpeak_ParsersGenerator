
import json

def merge_coordinates(data):
    if data["channel"]["latitude"] and data["channel"]["longitude"]:
        data["channel"]["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"
        del data['channel']['latitude']
        del data['channel']['longitude']
    return data

def write_to_file(data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 585444,
        "name": "Room Monitoring System",
        "description": "Temperature sensor for monitoring temperature",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2018-09-28T08:04:01Z",
        "updated_at": "2018-09-28T08:04:01Z",
        "last_entry_id": 5
    },
    "feeds": [
        {
            "created_at": "2018-09-28T08:25:38Z",
            "entry_id": 5,
            "field1": "20",
            "field2": null
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data = merge_coordinates(data)

# Create an empty output JSON with the schema structure
output_data = {
    "id": data["channel"]["id"],
    "temperature": data["channel"]["field1"] if data["channel"]["field1"] else None,
    "humidity": data["channel"]["field2"] if data["channel"]["field2"] else None,
    "location": data["channel"]["location"] if data["channel"]["location"] else None,
    # Add other fields according to the schema
    # ...
}

# Add feeds to the output data
output_data["feeds"] = data["feeds"]

# Write the output JSON to a file
write_to_file(output_data, "thingspeak/output_json/mistral/585444.json")
