
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1740260,
        "name": "Real-time weather sensing",
        "latitude": "10.8507214",
        "longitude": "106.7697336",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Pressure",
        "field4": "Light",
        "created_at": "2022-05-18T21:45:41Z",
        "updated_at": "2022-05-19T11:12:06Z",
        "last_entry_id": 1046
    },
    "feeds": [
        {
            "created_at": "2022-05-24T09:57:05Z",
            "entry_id": 1046,
            "field1": "33.80",
            "field2": "40.00",
            "field3": "1003.55",
            "field4": "1024.00"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["temperature"] = data["feeds"][0]["field1"]
output_data["humidity"] = data["feeds"][0]["field2"]
output_data["pressure"] = data["feeds"][0]["field3"]
output_data["light"] = data["feeds"][0]["field4"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Write output JSON to file
with open("thingspeak/output_json/mistral/1740260.json", "w") as outfile:
    json.dump(output_data, outfile, indent=4)
