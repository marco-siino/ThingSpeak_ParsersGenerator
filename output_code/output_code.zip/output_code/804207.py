
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 804207,
        "name": "ESP8266-12E",
        "description": "ESP8266-12E Weather",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "Light",
        "field4": "Atmosphere",
        "created_at": "2019-06-18T21:30:04Z",
        "updated_at": "2019-06-18T21:30:31Z",
        "last_entry_id": 4
    },
    "feeds": [
        {
            "created_at": "2019-06-18T21:59:43Z",
            "entry_id": 4,
            "field1": "22",
            "field2": "30",
            "field3": "213",
            "field4": "86682"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Create an empty output object
output = {}

# Iterate through the properties in the schema and fill the output object
for key, value in json.loads(json_schema)['properties'].items():
    if key in data['channel']:
        output[key] = data['channel'][key]

# Add feeds data to the output object
for feed in data['feeds']:
    for key, value in feed.items():
        if key in output:
            if output[key] is None:
                output[key] = value

# Write the output JSON to a file
with open('thingspeak/output_json/mistral/804207.json', 'w') as f:
    json.dump(output, f, indent=4)
