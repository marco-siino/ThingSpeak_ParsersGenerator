
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2380551,
        "name": "DSB WIFI CLOUD 59/2380551",
        "description": "Nextcon LTDA",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2023-12-14T15:21:47Z",
        "updated_at": "2023-12-14T15:22:38Z",
        "last_entry_id": 6124
    },
    "feeds": [
        {
            "created_at": "2024-01-11T16:15:37Z",
            "entry_id": 6124,
            "field1": "nan",
            "field2": "2147483648",
            "field3": "0.0"
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Extract relevant fields from the JSON text
output = {
    "id": data["channel"]["id"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    "temperature": data["channel"]["field1"],
    "humidity": None,
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None,
}

# If feeds exist, extract the relevant field values
if "feeds" in data and len(data["feeds"]) > 0:
    feed = data["feeds"][0]
    output["temperature"] = feed["field1"]

# Write the output JSON to a file
with open("thingspeak/output_json/mistral/2380551.json", "w") as f:
    json.dump(output, f, indent=4)
