
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 608347,
        "name": "Temperatur und Luftfeuchtigkeit",
        "description": "Luftfeuchtigkeit funktioniert noch nicht genau, wegen defekten Sensor.",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2018-10-23T19:22:22Z",
        "updated_at": "2018-10-23T19:57:48Z",
        "last_entry_id": 951
    },
    "feeds": [
        {
            "created_at": "2018-11-03T05:40:20Z",
            "entry_id": 951,
            "field1": "16.00",
            "field2": "67.00    "
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the input JSON
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/608347.json", "w") as f:
    json.dump(output_data, f, indent=4)
