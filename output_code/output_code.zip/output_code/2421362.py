
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 2421362,
        "name": "Heat Transfer (HT)",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2024-02-04T06:57:14Z",
        "updated_at": "2024-02-04T07:06:49Z",
        "last_entry_id": 26661
    },
    "feeds": [
        {
            "created_at": "2024-07-18T18:23:57Z",
            "entry_id": 26661,
            "field1": "29.60",
            "field2": "51.90"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Extract relevant data from JSON text
output = {
    "id": data["channel"]["id"],
    "temperature": data["feeds"][0]["field1"],
    "humidity": data["feeds"][0]["field2"],
    "location": f"{data['channel']['latitude']}, {data['channel']['longitude']}",
    # Add other fields with null values if not present in the JSON text
    "pressure": None,
    "light": None,
    "air_quality": None,
    "soil_moisture": None,
    "hardware": None,
    "distance": None,
    "ph": None
}

# Write output JSON to file
with open("thingspeak/output_json/mistral/2421362.json", "w") as f:
    json.dump(output, f, indent=4)
