
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1382183,
        "name": "Temperature and Humidity Monitoring",
        "description": "Temperature and Humidity monitoring system.",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2021-05-06T07:06:51Z",
        "updated_at": "2021-05-22T14:55:41Z",
        "last_entry_id": 641
    },
    "feeds": [
        {
            "created_at": "2021-05-24T06:23:12Z",
            "entry_id": 641,
            "field1": "29",
            "field2": null
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Create an empty output object
output = {}

# Iterate through the schema properties and fill the output object
for key, value in json.loads(schema)['properties'].items():
    if key in data['channel']:
        output[key] = data['channel'][key]

# Add feeds data if present
if 'feeds' in data:
    feed = data['feeds'][0]
    for key in json.loads(schema)['properties'].keys():
        if key in feed:
            if key == 'created_at' or key == 'entry_id':
                output[key] = feed[key]
            else:
                output[key] = feed[key] if feed[key] is not None else ''

# Write the output JSON to a file
with open('thingspeak/output_json/mistral/1382183.json', 'w') as f:
    json.dump(output, f, indent=4)
