
import json

# JSON text
data = """
{
    "channel": {
        "id": 622260,
        "name": "DHT11",
        "description": "Temperature and Humidity",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2018-11-08T21:33:41Z",
        "updated_at": "2018-11-18T12:59:48Z",
        "last_entry_id": 976
    },
    "feeds": [
        {
            "created_at": "2018-11-23T04:25:13Z",
            "entry_id": 976,
            "field1": "26.44    ",
            "field2": null
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
json_data = json.loads(data)
json_schema = json.loads(schema)

# Extract relevant fields from JSON data
output = {
    "id": json_data["channel"]["id"],
    "temperature": json_data["channel"]["field1"],
    "humidity": json_data["channel"]["field2"],
    "location": json_data["channel"]["latitude"] + "," + json_data["channel"]["longitude"],
    # Add other fields with null values if needed
}

# Write output to a file
with open("thingspeak/output_json/mistral/622260.json", "w") as f:
    json.dump(output, f, indent=4)
