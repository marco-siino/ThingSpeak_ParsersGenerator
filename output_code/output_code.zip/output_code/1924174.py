
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1924174,
        "name": "DSB WIFI SSI45/1924174",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Temperatura Min",
        "field3": "Temperatura Max",
        "created_at": "2022-11-07T19:46:04Z",
        "updated_at": "2022-11-07T19:55:06Z",
        "last_entry_id": 288195
    },
    "feeds": [
        {
            "created_at": "2024-06-13T19:54:01Z",
            "entry_id": 288195,
            "field1": "4.12500",
            "field2": "1.31250",
            "field3": "6.87500"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text and schema
data = json.loads(json_text)
schema = json.loads(json_schema)

# Prepare output data
output_data = {}
output_data["id"] = data["channel"]["id"]
output_data["location"] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Fill other fields based on the semantic of the JSON text
output_data["temperature"] = data["channel"]["field1"]
output_data["humidity"] = "null"  # Replace this with the appropriate value if available
output_data["pressure"] = "null"  # Replace this with the appropriate value if available
output_data["light"] = "null"  # Replace this with the appropriate value if available
output_data["air_quality"] = "null"  # Replace this with the appropriate value if available
output_data["soil_moisture"] = "null"  # Replace this with the appropriate value if available
output_data["hardware"] = "null"  # Replace this with the appropriate value if available
output_data["distance"] = "null"  # Replace this with the appropriate value if available
output_data["ph"] = "null"  # Replace this with the appropriate value if available

# Write output JSON to a file
with open("thingspeak/output_json/mistral/1924174.json", "w") as f:
    json.dump(output_data, f, indent=4)
