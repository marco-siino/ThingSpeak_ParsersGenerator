
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 1136455,
        "name": "Smart Home",
        "description": "To monitor humidity  and temperature in my home ",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "field3": "light",
        "created_at": "2020-09-07T02:52:32Z",
        "updated_at": "2020-09-07T07:57:55Z",
        "last_entry_id": 47
    },
    "feeds": [
        {
            "created_at": "2020-09-07T08:32:44Z",
            "entry_id": 47,
            "field1": "25.10",
            "field2": "60.00",
            "field3": "78"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output_json = {}
output_json['id'] = data['channel']['id']
output_json['temperature'] = data['feeds'][0]['field1']
output_json['humidity'] = data['feeds'][0]['field2']
output_json['light'] = data['channel']['field3']
output_json['location'] = data['channel']['location']

# Fill other fields with null values
output_json['air_quality'] = None
output_json['soil_moisture'] = None
output_json['hardware'] = None
output_json['distance'] = None
output_json['ph'] = None

# Write output JSON to file
with open('thingspeak/output_json/mistral/1136455.json', 'w') as f:
    json.dump(output_json, f, indent=4)
