
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 368505,
        "name": "wifi module",
        "description": "connecting temperature and humidity sensors",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperature",
        "field2": "Humidity",
        "created_at": "2017-11-20T10:43:31Z",
        "updated_at": "2017-11-20T11:29:57Z",
        "last_entry_id": 8
    },
    "feeds": [
        {
            "created_at": "2017-11-20T11:29:57Z",
            "entry_id": 8,
            "field1": "27.00",
            "field2": "59"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output JSON
output_json = {}

# Extract fields from data and fill output_json
for key, value in data['channel'].items():
    if key in json.loads(json_schema)['properties']:
        output_json[key] = value

# Process feeds and fill output_json
for feed in data['feeds']:
    for key, value in feed.items():
        if key in json.loads(json_schema)['properties']:
            if value != "0":
                output_json[key] = value

# Write output JSON to file
with open("thingspeak/output_json/mistral/368505.json", "w") as f:
    json.dump(output_json, f, indent=4)
