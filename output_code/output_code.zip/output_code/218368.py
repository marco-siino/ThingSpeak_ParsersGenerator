
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 218368,
        "name": "Temp",
        "description": "Mjerenje temperature",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "created_at": "2017-01-24T13:14:56Z",
        "updated_at": "2018-07-10T21:35:49Z",
        "last_entry_id": 15131
    },
    "feeds": [
        {
            "created_at": "2018-07-10T21:35:49Z",
            "entry_id": 15131,
            "field1": "32.38    "
        }
    ]
}
"""

# JSON schema
schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']}, {data['channel']['longitude']}"

# Initialize output data
output_data = {}
output_data['id'] = data['channel']['id']
output_data['location'] = data['channel']['location']
output_data['temperature'] = data['channel']['feeds'][0]['field1']

# Fill other fields with null values
for field in schema.replace("{", "{\n  '").replace("}", "\n}").split(",\n"):
    key, _ = field.split(":")
    output_data[key] = None

# Write output JSON to file
with open("thingspeak/output_json/mistral/218368.json", "w") as f:
    json.dump(output_data, f, indent=4)
