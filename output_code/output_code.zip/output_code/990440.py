
import json

# JSON text
json_text = """
{
    "channel": {
        "id": 990440,
        "name": "eemmerpan98",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "temperature",
        "field2": "humidity",
        "created_at": "2020-02-13T15:24:19Z",
        "updated_at": "2020-02-13T15:24:32Z",
        "last_entry_id": 71
    },
    "feeds": [
        {
            "created_at": "2020-02-14T15:01:58Z",
            "entry_id": 71,
            "field1": "30.40000",
            "field2": "75.80000"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge latitude and longitude into location
data['channel']['location'] = f"{data['channel']['latitude']},{data['channel']['longitude']}"

# Extract relevant fields from the JSON text
output = {
    "id": data['channel']['id'],
    "temperature": data['channel']['field1'],
    "humidity": data['channel']['field2'],
    "location": data['channel']['location'],
    # Add other fields as empty strings if they are not present in the JSON text
    "pressure": "",
    "light": "",
    "air_quality": "",
    "soil_moisture": "",
    "hardware": "",
    "distance": "",
    "ph": ""
}

# Add feeds data to the output
for feed in data['feeds']:
    output['temperature'] = feed['field1']
    output['humidity'] = feed['field2']

# Write output to a file
with open("thingspeak/output_json/mistral/990440.json", "w") as f:
    json.dump(output, f, indent=4)
