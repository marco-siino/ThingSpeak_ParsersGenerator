
import json

def merge_location(data):
    if data["channel"]["latitude"] and data["channel"]["longitude"]:
        data["channel"]["location"] = f"{data['channel']['latitude']},{data['channel']['longitude']}"
        del data['channel']['latitude']
        del data['channel']['longitude']
    return data

def write_to_file(data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

# JSON text
json_text = """
{
    "channel": {
        "id": 522752,
        "name": "demo",
        "latitude": "0.0",
        "longitude": "0.0",
        "field1": "Temperatura",
        "field2": "Humedad",
        "created_at": "2018-06-20T21:22:34Z",
        "updated_at": "2018-06-25T20:08:19Z",
        "last_entry_id": 4
    },
    "feeds": [
        {
            "created_at": "2018-06-25T20:08:19Z",
            "entry_id": 4,
            "field1": "19.6",
            "field2": "59"
        }
    ]
}
"""

# JSON schema
json_schema = """
{
    "type": "object",
    "properties": {
      "id": {
        "type": "string"
      },
      "temperature": {
        "type": "string"
      },
      "humidity": {
        "type": "string"
      },
      "pressure": {
        "type": "string"
      },
      "light": {
        "type": "string"
      },
      "air_quality": {
        "type": "string"
      },
      "location": {
        "type": "string"
      },
      "soil_moisture": {
        "type": "string"
      },
      "hardware": {
        "type": "string"
      },
      "distance": {
        "type": "string"
      },
      "ph": {
        "type": "string"
      }
    }
}
"""

# Parse JSON text
data = json.loads(json_text)

# Merge location field
data = merge_location(data)

# Create output JSON based on schema
output_data = {}
for key, value in json.loads(json_schema)["properties"].items():
    if key in data["channel"]:
        output_data[key] = data["channel"][key]

# Add feeds data
for feed in data["feeds"]:
    for key, value in json.loads(json_schema)["properties"].items():
        if key in feed:
            if key not in output_data:
                output_data[key] = []
            output_data[key].append(feed[key])

# Write output JSON to file
write_to_file(output_data, "thingspeak/output_json/mistral/522752.json")
